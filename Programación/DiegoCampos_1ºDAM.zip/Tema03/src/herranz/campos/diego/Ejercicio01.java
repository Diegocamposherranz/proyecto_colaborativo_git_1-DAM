package herranz.campos.diego;
import java.util.Scanner;
public class Ejercicio01 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Dado un número escribir “Demasiado joven” o “Viejales” en función de que dicho número sea menor o igual que tu edad o estrictamente mayor
	
	Scanner sc = new Scanner(System.in);

	        // Pedimos un número
	System.out.print("Introduce un número: ");
	int numero = sc.nextInt();

	        // Definimos la edad (puedes cambiarla por la tuya)
	int miEdad = 25;

	        // Comprobamos la condición
	if (numero <= miEdad) {
	System.out.println("Demasiado joven");
	} else {
	System.out.println("Viejales");
	        }

	        sc.close();

	}

}
