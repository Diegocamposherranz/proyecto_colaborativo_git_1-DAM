package herranz.campos.diego;

public class Ejercicio07 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Mostrar los números desde el 5 hasta el 10 (utilizando una sola sentencia “print”)*/
		System.out.print("Los números del 5 al 10 son: ");
        for (int i = 5; i <= 10; i++) {
            System.out.print(i + " ");
        }
    }

	}
