package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio21 {
    public static void main(String[] args) {
        // 21. Dado un número entero mayor que cero, indicar cuántos dígitos tiene.
        // Introducir el número en un bucle e irlo dividiendo por 10 hasta que sea menor que cero.
        // Llevar un contador para ver cuántas vueltas se dan al bucle. Ese número será el número de cifras.

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número entero mayor que 0: ");
        int n = sc.nextInt();

        int contador = 0;
        while (n > 0) {
            n = n / 10;
            contador++;
        }

        System.out.println("El número tiene " + contador + " dígitos.");
        sc.close();
    }
}
