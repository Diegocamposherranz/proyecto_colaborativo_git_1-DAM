package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio28 {
    public static void main(String[] args) {
        // 28. Dados dos números, indicar el máximo común divisor de ambos.
        // Usar el algoritmo de Euclides.

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce el primer número: ");
        int x = sc.nextInt();
        System.out.print("Introduce el segundo número: ");
        int y = sc.nextInt();

        int a = Math.max(x, y);
        int b = Math.min(x, y);

        while (b != 0) {
            int resto = a % b;
            a = b;
            b = resto;
        }

        System.out.println("El MCD de " + x + " y " + y + " es: " + a);
        sc.close();
    }
}
