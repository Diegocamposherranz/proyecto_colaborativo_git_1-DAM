package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio36 {
    public static void main(String[] args) {
        // 36. Dado un número n (1 <= n <= 20), dibujar un cuadrado de n x n asteriscos.

        Scanner sc = new Scanner(System.in);
        int n;

        System.out.println("--- DIBUJAR UN CUADRADO DE N x N ASTERISCOS ---");
        System.out.print("Introduce un número n (entre 1 y 20): ");
        
        if (!sc.hasNextInt()) {
            System.out.println("Error: Debes introducir un número entero.");
            sc.close();
            return;
        }

        n = sc.nextInt();
        sc.close();

        // Validación del rango 1 <= n <= 20
        if (n < 1 || n > 20) {
            System.out.println("Error: El número debe estar en el rango de 1 a 20.");
            return;
        }

        System.out.println("\nFigura para n = " + n + ":");

        // Bucle EXTERIOR: Controla las filas (se repite n veces)
        for (int fila = 0; fila < n; fila++) {
            
            // Bucle INTERIOR: Dibuja una fila de n asteriscos
            for (int columna = 0; columna < n; columna++) {
                // Imprime el asterisco SIN salto de línea
                System.out.print("*");
            }
            
            // Salto de línea: Mueve el cursor a la siguiente fila después de completar una
            System.out.println();
        }
    }
}