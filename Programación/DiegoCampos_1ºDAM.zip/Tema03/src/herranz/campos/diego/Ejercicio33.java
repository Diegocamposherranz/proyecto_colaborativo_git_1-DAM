package herranz.campos.diego;

public class Ejercicio33 {
    public static void main(String[] args) {
        // 33. Calcular el sumatorio: ∑_{i=1}^{100} (i^2 + 1) / i
        
        final int LIMITE_SUPERIOR = 100;

        // Se usa 'double' para la acumuladora, ya que el sumatorio incluye términos fraccionarios.
        double sumatorio = 0.0; 
        
        System.out.println("--- CÁLCULO DEL SUMATORIO (i^2 + 1) / i ---");
        System.out.println("Sumando desde i=1 hasta i=" + LIMITE_SUPERIOR);

        // Bucle que recorre desde i = 1 hasta i = 100
        for (int i = 1; i <= LIMITE_SUPERIOR; i++) {
            
            // 1. Calculamos el término actual: (i^2 + 1) / i
            // Es vital que uno de los operandos sea double para forzar la división decimal.
            double numerador = (double)i * i + 1.0; 
            double terminoActual = numerador / i;
            
            // 2. Acumulamos el término
            sumatorio = sumatorio + terminoActual;
            
            // Opcionalmente, mostrar términos parciales para seguimiento (descomentar para ver)
            // System.out.printf("i=%d, Término=%.4f, Suma Parcial=%.4f\n", i, terminoActual, sumatorio);
        }

        // Mostrar el resultado con formato para una mejor visualización de la precisión
        System.out.printf("\nEl valor final del sumatorio es: %.6f\n", sumatorio);
        
        // El resultado esperado es aproximadamente 5050.518737
    }
}