package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio20 {
    public static void main(String[] args) {
        // 20. Dado un número entero mayor que cero, escribirlo en orden inverso.
        // (ej. Dado 1234, mostraría 4321)
        // Obtener las unidades de “n” observando el resto de dividir “n” por 10.
        // Imprimir esas unidades por pantalla y repetir el proceso con la décima parte de “n”.

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número entero mayor que 0: ");
        int n = sc.nextInt();

        System.out.print("Número invertido: ");
        while (n > 0) {
            int resto = n % 10;
            System.out.print(resto);
            n = n / 10;
        }

        System.out.println();
        sc.close();
    }
}
