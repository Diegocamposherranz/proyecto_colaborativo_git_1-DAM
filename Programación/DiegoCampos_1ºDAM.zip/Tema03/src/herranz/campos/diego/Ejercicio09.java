package herranz.campos.diego;

public class Ejercicio09 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Mostrar los números desde el 10 hasta el 4 (utilizando una sola sentencia “print”) */
		System.out.print("Los números del 10 al 4 son: ");
        for (int i = 10; i >= 4; i--) {
            System.out.print(i + " ");
        }
    }
	}