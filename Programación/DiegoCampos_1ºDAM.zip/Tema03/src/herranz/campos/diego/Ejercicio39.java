package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio39 {
    public static void main(String[] args) {
        // 39. Dibujar 'm' montañas de altura 'a'.

        Scanner sc = new Scanner(System.in);
        int a, m;

        System.out.println("--- DIBUJAR M MONTAÑAS DE ALTURA A ---");
        
        System.out.print("Introduce la altura de la montaña (a, ej. 3): ");
        if (!sc.hasNextInt()) {
            System.out.println("Error: Debes introducir un número entero para la altura.");
            sc.close();
            return;
        }
        a = sc.nextInt();

        System.out.print("Introduce el número de montañas a dibujar (m, ej. 4): ");
        if (!sc.hasNextInt()) {
            System.out.println("Error: Debes introducir un número entero para la cantidad de montañas.");
            sc.close();
            return;
        }
        m = sc.nextInt();
        
        sc.close();

        // Validación básica (asumimos 1 <= a <= 20 y m > 0)
        if (a < 1 || m < 1) {
            System.out.println("Error: La altura (a) y la cantidad de montañas (m) deben ser mayores a 0.");
            return;
        }

        System.out.println("\nFigura para altura a=" + a + " y cantidad m=" + m + ":");

        // BUCLE EXTERIOR: Se repite 'm' veces, una por cada montaña
        for (int montaña = 1; montaña <= m; montaña++) {
            
            // PARTE 1: Bucle ASCENDENTE (Subida de la montaña, de 1 a 'a')
            // i representa el número de asteriscos a dibujar en la fila actual.
            for (int i = 1; i <= a; i++) {
                
                // Bucle interior: Dibuja 'i' asteriscos en la fila
                for (int j = 1; j <= i; j++) {
                    System.out.print("*");
                }
                
                // Salto de línea
                System.out.println();
            }

            // PARTE 2: Bucle DESCENDENTE (Bajada de la montaña, de 'a-1' a 1)
            // Empezamos en a-1 para no repetir la fila más larga.
            for (int i = a - 1; i >= 1; i--) {
                
                // Bucle interior: Dibuja 'i' asteriscos en la fila
                for (int j = 1; j <= i; j++) {
                    System.out.print("*");
                }
                
                // Salto de línea
                System.out.println();
            }
        }
    }
}