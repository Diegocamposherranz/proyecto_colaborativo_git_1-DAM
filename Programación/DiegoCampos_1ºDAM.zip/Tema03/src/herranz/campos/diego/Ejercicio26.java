package herranz.campos.diego;

public class Ejercicio26 {
    public static void main(String[] args) {
        // 26. Mostrar los números primos existentes entre 2 y 100.
        // Hacer un método “boolean primo(int n)” que devuelva true si n es primo y false en caso contrario.

        System.out.println("Números primos entre 2 y 100:");
        for (int i = 2; i <= 100; i++) {
            if (primo(i)) {
                System.out.print(i + " ");
            }
        }
        System.out.println();
    }

    public static boolean primo(int n) {
        if (n < 2) return false;
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) return false;
        }
        return true;
    }
}
