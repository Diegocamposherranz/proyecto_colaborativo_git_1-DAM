package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio17 {
    public static void main(String[] args) {
        // 17. Leer números por teclado de manera que sólo permita que el recién leído sea mayor que el 
        // anterior. En el momento que esto no se cumpla el programa se detiene. La lectura del 
        // primer número siempre será exitosa, ya que no hay ningún número con el que compararlo. 
        // Hacer una primera lectura de “n” fuera del bucle. Utilizar un bucle do..while en el 
        // que se guarde el valor de “n” en una variable “ant”, se lea el nuevo “n” y se 
        // permanezca en el bucle si n > ant.
        
        Scanner sc = new Scanner(System.in);
        int ant, n;
        
        System.out.print("Introduce un número: ");
        ant = sc.nextInt(); // primera lectura, siempre válida
        
        do {
            System.out.print("Introduce un número mayor que " + ant + ": ");
            n = sc.nextInt();
            
            if (n > ant) {
                ant = n; // actualizar el anterior si es mayor
            }
        } while (n > ant); // se repite mientras el nuevo sea mayor que el anterior
        
        System.out.println("El número introducido no es mayor. Programa finalizado.");
        
        sc.close();
    }
}
