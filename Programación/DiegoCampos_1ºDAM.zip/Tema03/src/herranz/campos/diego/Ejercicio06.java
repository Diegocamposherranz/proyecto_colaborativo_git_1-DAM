package herranz.campos.diego;

public class Ejercicio06 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Mostrar los 10 primeros números (utilizando una sola sentencia “print”) */
		System.out.print("Los 10 primeros números son: ");
        for (int i = 1; i <= 10; i++) {
            System.out.print(i + " ");
        }
    }

	}
