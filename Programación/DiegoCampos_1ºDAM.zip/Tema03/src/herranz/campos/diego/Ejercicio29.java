package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio29 {
    public static void main(String[] args) {
        // 29. Dado un número n, mostrar los n primeros términos de la serie de Fibonacci.
        // La serie comienza con 0 y 1; cada número es la suma de los dos anteriores.

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce cuántos términos mostrar: ");
        int n = sc.nextInt();

        int a = 0, b = 1;

        System.out.print("Serie de Fibonacci: ");
        for (int i = 1; i <= n; i++) {
            System.out.print(a + " ");
            int siguiente = a + b;
            a = b;
            b = siguiente;
        }

        System.out.println();
        sc.close();
    }
}
