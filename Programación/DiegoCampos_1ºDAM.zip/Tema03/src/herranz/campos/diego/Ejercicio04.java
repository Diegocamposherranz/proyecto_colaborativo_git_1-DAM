package herranz.campos.diego;

public class Ejercicio04 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Dado un número, mostrar por pantalla su nombre (es decir, si es 1, “UNO”, si es 2, “DOS”, 
		si es 3, “TRES”, y si es cualquier otro número que muestre “NO SÉ). Hacer una versión alternativa utilizando “switch”. */
		   // ---- Usando if...else ----
	int numero = 2;
    if (numero == 1) {
    System.out.println("if: UNO");
    } else if (numero == 2) {
    System.out.println("if: DOS");
    } else if (numero == 3) {
    System.out.println("if: TRES");
    } else {
    System.out.println("if: NO SÉ");
        }

        // ---- Usando switch ----
    switch (numero) {
    case 1:
    System.out.println("switch: UNO");
    break;
    case 2:
    System.out.println("switch: DOS");
    break;
    case 3:
    System.out.println("switch: TRES");
    break;
    default:
    System.out.println("switch: NO SE");
        }
    }
}

