package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio40 {
    public static void main(String[] args) {
        // 40. Dado un número n (1 <= n <= 20), dibujar un triángulo invertido y alineado a la derecha.

        Scanner sc = new Scanner(System.in);
        int n;

        System.out.println("--- DIBUJAR UN TRIÁNGULO INVERSO ALINEADO A LA DERECHA ---");
        System.out.print("Introduce un número n (base del triángulo, entre 1 y 20): ");
        
        if (!sc.hasNextInt()) {
            System.out.println("Error: Debes introducir un número entero.");
            sc.close();
            return;
        }

        n = sc.nextInt();
        sc.close();

        // Validación del rango 1 <= n <= 20
        if (n < 1 || n > 20) {
            System.out.println("Error: El número debe estar en el rango de 1 a 20.");
            return;
        }

        System.out.println("\nFigura para n = " + n + ":");

        // Bucle EXTERIOR (i): Controla las filas (desde 1 hasta n).
        for (int i = 1; i <= n; i++) {
            
            // BUCLE INTERIOR 1 (Espacios): Imprime los espacios necesarios.
            // Los espacios son: n - i
            // Fila 1 (i=1) -> n-1 espacios
            // Fila n (i=n) -> 0 espacios
            for (int espacios = 1; espacios <= n - i; espacios++) {
                System.out.print(" ");
            }
            
            // BUCLE INTERIOR 2 (Asteriscos): Imprime los asteriscos.
            // Los asteriscos son: i
            for (int asteriscos = 1; asteriscos <= i; asteriscos++) {
                System.out.print("*");
            }
            
            // Salto de línea: Termina la fila y pasa a la siguiente.
            System.out.println();
        }
    }
}