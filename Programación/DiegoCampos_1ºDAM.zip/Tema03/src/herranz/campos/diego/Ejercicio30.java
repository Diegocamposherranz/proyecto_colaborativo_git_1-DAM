package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio30 {
    public static void main(String[] args) {
        // 30. Dado un número n, mostrar n! (n! = n * (n-1) * ... * 1).
        // Se utiliza una variable "acc" acumuladora que empieza en 1.

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número entero no negativo (n): ");
        
        if (!sc.hasNextInt()) {
            System.out.println("Entrada no válida. Debe ser un número entero.");
            sc.close();
            return;
        }

        int n = sc.nextInt();
        sc.close();

        if (n < 0) {
            System.out.println("El factorial no está definido para números negativos.");
            return;
        }
        
        // El factorial crece muy rápido. Usamos 'long' para más capacidad.
        // n > 20 excede el límite de 'long'.
        if (n > 20) {
            System.out.println("ADVERTENCIA: n! excede el límite del tipo 'long'. El resultado podría ser incorrecto.");
        }

        // 1. Inicialización de la variable acumuladora 'acc'.
        // Es crucial que sea 1, ya que 0! = 1.
        long acc = 1;

        // 2. Bucle que va desde 1 hasta n para acumular las multiplicaciones parciales.
        // Si n=0, el bucle no se ejecuta y retorna acc=1.
        for (int i = 1; i <= n; i++) {
            // Actualización: acc = acc * i
            acc = acc * i;
        }

        System.out.println("El factorial de " + n + " es: " + acc);
    }
}