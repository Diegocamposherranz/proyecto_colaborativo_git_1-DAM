package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio13 {
    public static void main(String[] args) {
        // 13. Pedir un número por teclado y mostrar la tabla de multiplicar de ese número 
        // (utilizando una sola sentencia “print”)
        
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número: ");
        int n = sc.nextInt();
        
        System.out.print(
            n + " x 1 = " + (n*1) + "\n" +
            n + " x 2 = " + (n*2) + "\n" +
            n + " x 3 = " + (n*3) + "\n" +
            n + " x 4 = " + (n*4) + "\n" +
            n + " x 5 = " + (n*5) + "\n" +
            n + " x 6 = " + (n*6) + "\n" +
            n + " x 7 = " + (n*7) + "\n" +
            n + " x 8 = " + (n*8) + "\n" +
            n + " x 9 = " + (n*9) + "\n" +
            n + " x 10 = " + (n*10)
        );
        
        sc.close();
    }
}
