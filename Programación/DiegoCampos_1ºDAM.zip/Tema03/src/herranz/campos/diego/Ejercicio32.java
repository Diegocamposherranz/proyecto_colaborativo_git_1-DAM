package herranz.campos.diego;

public class Ejercicio32 {
    public static void main(String[] args) {
        // 32. Mostrar los 5 primeros términos de la serie: xi = xi-1 * 3, sabiendo que x1=1.

        // El número de términos a mostrar es fijo: 5.
        final int N_TERMINOS = 5;

        // x1 = 1, la variable 'terminoActual' guardará el valor de xi.
        long terminoActual = 1; 

        System.out.println("--- SERIE x(i) = x(i-1) * 3 ---");
        System.out.print("Los " + N_TERMINOS + " primeros términos son: ");
        
        // Usamos un bucle para calcular y mostrar los N_TERMINOS
        for (int i = 1; i <= N_TERMINOS; i++) {
            
            // 1. Mostrar el término actual (xi-1, excepto en la primera iteración que es x1)
            System.out.print(terminoActual);
            
            // Agregar un separador, excepto después del último término
            if (i < N_TERMINOS) {
                System.out.print(", ");
            }

            // 2. Calcular el siguiente término (xi) usando la relación de recurrencia: xi = xi-1 * 3
            // La variable 'terminoActual' se prepara para la siguiente iteración.
            terminoActual = terminoActual * 3;
        }

        System.out.println();
        
        // Los 5 términos son: 1, 3, 9, 27, 81
    }
}