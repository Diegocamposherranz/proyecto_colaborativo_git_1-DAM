package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio38 {
    public static void main(String[] args) {
        // 38. Modificar el programa anterior (Ejercicio 37) para dibujar la "bajada de la montaña".

        Scanner sc = new Scanner(System.in);
        int n;

        System.out.println("--- DIBUJAR UNA MONTAÑA DE ASTERISCOS (SUBIDA Y BAJADA) ---");
        System.out.print("Introduce un número n (altura central, entre 1 y 20): ");
        
        if (!sc.hasNextInt()) {
            System.out.println("Error: Debes introducir un número entero.");
            sc.close();
            return;
        }

        n = sc.nextInt();
        sc.close();

        // Validación del rango 1 <= n <= 20
        if (n < 1 || n > 20) {
            System.out.println("Error: El número debe estar en el rango de 1 a 20.");
            return;
        }

        System.out.println("\nFigura para n = " + n + ":");

        // PARTE 1: Bucle ASCENDENTE (Subida de la montaña, de 1 a n)
        for (int i = 1; i <= n; i++) {
            
            // Bucle interior: Dibuja 'i' asteriscos
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            
            // Salto de línea
            System.out.println();
        }

        // PARTE 2: Bucle DESCENDENTE (Bajada de la montaña, de n-1 a 1)
        // Empezamos en n-1 para no repetir la fila más larga (que ya se dibujó con i=n en el bucle anterior).
        for (int i = n - 1; i >= 1; i--) {
            
            // Bucle interior: Dibuja 'i' asteriscos
            for (int j = 1; j <= i; j++) {
                System.out.print("*");
            }
            
            // Salto de línea
            System.out.println();
        }
    }
}