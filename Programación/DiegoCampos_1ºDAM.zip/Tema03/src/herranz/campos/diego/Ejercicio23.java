package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio23 {
    public static void main(String[] args) {
        // 23. Indicar la suma de los dígitos de un número (ej. 178 = 16)
        // Utilizar una variable acumuladora “acc” que vaya sumando las cifras.

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número entero: ");
        int n = sc.nextInt();

        int acc = 0;
        while (n > 0) {
            acc += n % 10;
            n = n / 10;
        }

        System.out.println("La suma de los dígitos es: " + acc);
        sc.close();
    }
}
