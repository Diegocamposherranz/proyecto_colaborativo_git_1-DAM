package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio31 {

    // Se usa 'long' en lugar de 'int' para el factorial por razones de robustez.
    // Aunque el enunciado pide 'int fact(int n)', se usa 'long' para evitar overflow 
    // en factoriales incluso moderadamente grandes (n > 12).
    public static long fact(int n) {
        if (n < 0) {
            // El factorial no está definido para números negativos.
            throw new IllegalArgumentException("Factorial no definido para n < 0.");
        }
        
        long acc = 1;
        
        // Bucle descendente (optimización de implementación del Ejercicio 30)
        for (int i = n; i >= 1; i--) {
            acc *= i;
        }
        
        return acc;
    }

    // Método para calcular el número combinatorio con optimización
    public static long calcularCombinatorio(int n, int k) {
        if (k < 0 || k > n) {
            return 0;
        }
        
        // OPTIMIZACIÓN 1: Uso de la simetría C(n, k) = C(n, n-k)
        // Esto reduce el número de multiplicaciones si k > n/2.
        if (k > n / 2) {
            k = n - k;
        }

        long resultado = 1;
        
        // OPTIMIZACIÓN 2: Uso de la fórmula simplificada por multiplicación/división sucesiva.
        // C(n, k) = [n * (n-1) * ... * (n-k+1)] / [k * (k-1) * ... * 1]
        // Esto evita calcular los factoriales grandes por separado y reduce el riesgo de overflow.
        for (int i = 1; i <= k; i++) {
            // Multiplicamos por el término del numerador (n - i + 1)
            // y luego dividimos por el término del denominador (i).
            // Dado que C(n, k) siempre es entero, la división será exacta.
            resultado = resultado * (n - i + 1) / i;
        }

        return resultado;
    }


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n, k;

        System.out.println("--- CÁLCULO DEL NÚMERO COMBINATORIO C(n, k) ---");
        
        System.out.print("Introduce el valor de n (n >= k): ");
        n = sc.nextInt();
        
        System.out.print("Introduce el valor de k (n >= k): ");
        k = sc.nextInt();
        
        sc.close();

        if (n < k || n < 0 || k < 0) {
            System.out.println("Error: Se requiere n >= k >= 0.");
            return;
        }
        
        long combinatorio = calcularCombinatorio(n, k);
        
        System.out.println("\nEl número combinatorio C(" + n + ", " + k + ") es: " + combinatorio);
        
        // Comprobación opcional de la fórmula clásica (PELIGRO DE OVERFLOW)
        /*
        try {
            long nFact = fact(n);
            long kFact = fact(k);
            long nkFact = fact(n - k);
            long combinatorioClasico = nFact / (kFact * nkFact);
            System.out.println("(Verificación con fórmula clásica: " + combinatorioClasico + ")");
        } catch (ArithmeticException e) {
            System.out.println("(El cálculo clásico n!/(k!(n-k)!) produce overflow y no se puede verificar con long)");
        }
        */
    }
}