package herranz.campos.diego;

public class Ejercicio08 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Mostrar los números desde el 10 hasta el 1 (utilizando una sola sentencia “print”) */
		System.out.print("Los números del 10 al 1 son: ");
        for (int i = 10; i >= 1; i--) {
            System.out.print(i + " ");
        }
    }
	}
