package herranz.campos.diego;
import java.util.Scanner;
public class Ejercicio05 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Dada una letra indicar si es una vocal o una consonante. */
	Scanner scan = new Scanner(System.in);
	System.out.print("Introduce una letra: ");
    String letra = scan.next(); // lee la siguiente entrada del usuario

    // Convertimos a minúscula para simplificar la comparación
    letra = letra.toLowerCase();

    // Comprobamos que solo sea una letra
    if (letra.length() != 1 || !Character.isLetter(letra.charAt(0))) {
    System.out.println("Por favor, introduce solo una letra.");
    } else {
        switch (letra) {
            case "a":
            case "e":
            case "i":
            case "o":
            case "u":
                System.out.println("Es una vocal.");
                break;
            default:
                System.out.println("Es una consonante.");
                break;
        }
    }

    scan.close();
	}
}