package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio25 {
    public static void main(String[] args) {
        // 25. Dado un número mayor que cero, indicar si es primo o no.
        // Comprobar si es divisible por algún número entre 2 y n-1.

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número entero mayor que 1: ");
        int n = sc.nextInt();

        boolean primo = true;
        for (int i = 2; i < n; i++) {
            if (n % i == 0) {
                primo = false;
                break;
            }
        }

        if (primo) System.out.println("El número es primo.");
        else System.out.println("El número no es primo.");

        sc.close();
    }
}
