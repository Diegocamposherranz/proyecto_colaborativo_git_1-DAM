package herranz.campos.diego;
import java.util.Scanner;
public class Ejercicio02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Dado un número escribir “Buena edad”, “Demasiado joven” o “Viejales” en función de que dicho número sea igual, menor o mayor que nuestra edad.
	Scanner sc = new Scanner(System.in);

        // Pedimos un número
    System.out.print("Introduce un número: ");
    int numero = sc.nextInt();

        // Definimos tu edad (puedes cambiarla por la tuya)
    int miEdad = 25;

        // Comparamos con if...else if...else
    if (numero == miEdad) {
    System.out.println("Buena edad");
    } else if (numero < miEdad) {
    System.out.println("Demasiado joven");
    } else {
    System.out.println("Viejales");
        }

        sc.close();
	}

}
