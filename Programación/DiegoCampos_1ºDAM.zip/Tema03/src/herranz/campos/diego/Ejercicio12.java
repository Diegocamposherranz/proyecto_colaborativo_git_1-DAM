package herranz.campos.diego;

public class Ejercicio12 {
    public static void main(String[] args) {
        // 12. Mostrar la tabla de multiplicar del 4 (utilizando una sola sentencia “print”)
        
        System.out.print(
            "4 x 1 = " + (4*1) + "\n" +
            "4 x 2 = " + (4*2) + "\n" +
            "4 x 3 = " + (4*3) + "\n" +
            "4 x 4 = " + (4*4) + "\n" +
            "4 x 5 = " + (4*5) + "\n" +
            "4 x 6 = " + (4*6) + "\n" +
            "4 x 7 = " + (4*7) + "\n" +
            "4 x 8 = " + (4*8) + "\n" +
            "4 x 9 = " + (4*9) + "\n" +
            "4 x 10 = " + (4*10)
        );
    }
}

