package herranz.campos.diego;

public class Ejercicio10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*Mostrar los números IMPARES que haya (en orden) desde el 1 hasta el 10 (utilizando una 
		  sola sentencia “print”) */
	System.out.print("Los números impares del 1 al 10 son: ");
	for (int i = 1; i <= 10; i++) {
	if (i % 2 != 0) { // comprobamos si es impar
	System.out.print(i + " ");
	            }
	        }
	}

}
