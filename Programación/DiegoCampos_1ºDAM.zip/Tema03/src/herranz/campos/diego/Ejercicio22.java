package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio22 {
    public static void main(String[] args) {
        // 22. Indicar si un número entero mayor que cero, introducido, es capicúa.
        // Crear un método “int reves(int n)” que devuelva el inverso de un número.
        // Para ver que “n” sea capicúa basta con que n sea igual a reves(n).

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número entero mayor que 0: ");
        int n = sc.nextInt();

        if (n == reves(n)) {
            System.out.println("El número es capicúa.");
        } else {
            System.out.println("El número no es capicúa.");
        }

        sc.close();
    }

    public static int reves(int n) {
        int inverso = 0;
        while (n > 0) {
            inverso = inverso * 10 + (n % 10);
            n = n / 10;
        }
        return inverso;
    }
}
