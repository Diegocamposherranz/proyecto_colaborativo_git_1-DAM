package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio37 {
    public static void main(String[] args) {
        // 37. Dado un número n (1 <= n <= 20), dibujar un triángulo rectángulo de n asteriscos de base.

        Scanner sc = new Scanner(System.in);
        int n;

        System.out.println("--- DIBUJAR UN TRIÁNGULO RECTÁNGULO DE ASTERISCOS ---");
        System.out.print("Introduce un número n (base del triángulo, entre 1 y 20): ");
        
        if (!sc.hasNextInt()) {
            System.out.println("Error: Debes introducir un número entero.");
            sc.close();
            return;
        }

        n = sc.nextInt();
        sc.close();

        // Validación del rango 1 <= n <= 20
        if (n < 1 || n > 20) {
            System.out.println("Error: El número debe estar en el rango de 1 a 20.");
            return;
        }

        System.out.println("\nFigura para n = " + n + ":");

        // Bucle EXTERIOR (i): Controla las filas y la cantidad de asteriscos a dibujar en esa fila.
        // i va de 1 (primera fila) hasta n (última fila/base).
        for (int i = 1; i <= n; i++) {
            
            // Bucle INTERIOR (j): Dibuja los asteriscos de la fila actual.
            // Se repite 'i' veces.
            for (int j = 1; j <= i; j++) {
                // Imprime el asterisco SIN salto de línea.
                System.out.print("*");
            }
            
            // Salto de línea: Mueve el cursor a la siguiente fila.
            System.out.println();
        }
    }
}