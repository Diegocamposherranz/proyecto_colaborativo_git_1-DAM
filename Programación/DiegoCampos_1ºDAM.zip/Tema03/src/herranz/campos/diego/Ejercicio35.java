package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio35 {
    public static void main(String[] args) {
        // 35. Dado un número n (1 <= n <= 20), dibujar una fila de n asteriscos.

        Scanner sc = new Scanner(System.in);
        int n;

        System.out.println("--- DIBUJAR UNA FILA DE ASTERISCOS ---");
        System.out.print("Introduce un número n (entre 1 y 20): ");
        
        if (!sc.hasNextInt()) {
            System.out.println("Error: Debes introducir un número entero.");
            sc.close();
            return;
        }

        n = sc.nextInt();
        sc.close();

        // Validación del rango 1 <= n <= 20
        if (n < 1 || n > 20) {
            System.out.println("Error: El número debe estar en el rango de 1 a 20.");
            return;
        }

        System.out.println("\nFigura para n = " + n + ":");

        // Bucle para dibujar la fila. Se ejecuta n veces.
        for (int i = 0; i < n; i++) {
            // Utilizamos print() para imprimir el asterisco SIN salto de línea.
            System.out.print("*");
        }
        
        // Al finalizar el bucle, agregamos un salto de línea para terminar la figura y limpiar la consola.
        System.out.println();
    }
}