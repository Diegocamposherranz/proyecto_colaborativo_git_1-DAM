package herranz.campos.diego;
import java.util.Scanner;
public class Ejercicio03 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Dado un número, indicar por pantalla si es par o impar.
	Scanner sc = new Scanner(System.in);
		// Pedimos el número
	System.out.println("Introduce un número: ");
	int numero = sc.nextInt();
		// Comprobamos si el número es par o impar
	if (numero % 2 == 0) {
	System.out.println("Si el número es par ");
	} else{
    System.out.println("El número es impar");
    }

    sc.close();
	}

}
