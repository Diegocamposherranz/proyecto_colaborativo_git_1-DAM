package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio27 {
    public static void main(String[] args) {
        // 27. Dados dos números a y b, mostrar los números primos que existen entre ellos.
        // Apoyarse en el método primo() del ejercicio anterior.

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce el número inicial (a): ");
        int a = sc.nextInt();
        System.out.print("Introduce el número final (b): ");
        int b = sc.nextInt();

        System.out.println("Números primos entre " + a + " y " + b);
        for (int i = a; i <= b; i++) {
            if (primo(i)) System.out.print(i + " ");
        }
        System.out.println();
        sc.close();
    }

    public static boolean primo(int n) {
        if (n < 2) return false;
        for (int i = 2; i <= Math.sqrt(n); i++) {
            if (n % i == 0) return false;
        }
        return true;
    }
}
