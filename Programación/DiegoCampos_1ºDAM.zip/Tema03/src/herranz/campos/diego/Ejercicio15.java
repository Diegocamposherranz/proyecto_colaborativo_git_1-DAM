package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio15 {
    public static void main(String[] args) {
        // 15. Pedir un número por teclado y mostrar las tablas de multiplicar desde el 1 hasta ese 
        // número introducido (utilizando una sola sentencia “print”)
        
        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número: ");
        int n = sc.nextInt();
        
        String salida = ""; // Aquí vamos acumulando el texto de todas las tablas
        
        for (int i = 1; i <= n; i++) {
            salida += "TABLA DEL " + i + "\n";
            for (int j = 1; j <= 10; j++) {
                salida += i + " x " + j + " = " + (i * j) + "\n";
            }
            salida += "\n"; // Salto de línea entre tablas
        }
        
        System.out.print(salida); // ÚNICA SENTENCIA PRINT
        
        sc.close();
    }
}
