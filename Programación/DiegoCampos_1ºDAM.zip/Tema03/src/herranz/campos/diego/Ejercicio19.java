package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio19 {
    public static void main(String[] args) {
        // 19. Leer números, permitiendo únicamente que el recién leído sea mayor que el anterior.
        // En caso contrario se debe leer otro número. Detenerse cuando se introduzca el cero.
        // Igual que el 18, excepto que la condición de permanencia en el bucle es únicamente que sea distinto de cero.
        // Dentro del bucle, y después de leer el nuevo “n” se deberá comprobar con un if que n>ant,
        // escribiendo por pantalla “n” si fuera cierto, y no haciendo nada en caso contrario.

        Scanner sc = new Scanner(System.in);
        int ant, n;

        System.out.print("Introduce un número inicial (distinto de 0): ");
        ant = sc.nextInt();

        do {
            System.out.print("Introduce un número mayor que " + ant + " (0 para detener): ");
            n = sc.nextInt();

            if (n > ant) {
                System.out.println("Correcto: " + n);
                ant = n; // actualizar el anterior
            }
        } while (n != 0);

        System.out.println("Se introdujo el número 0. Programa finalizado.");
        sc.close();
    }
}
