package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio16 {
    public static void main(String[] args) {
        // 16. Leer números por teclado de manera que al escribir el número 0, pare el proceso y se 
        // dejen de leer números. 
        // Utilizar un bucle do..while, que lea un número “n” y permanezca en el bucle si n es 
        // distinto a cero.
        
        Scanner sc = new Scanner(System.in);
        int n;
        
        do {
            System.out.print("Introduce un número (0 para salir): ");
            n = sc.nextInt();
        } while (n != 0);
        
        System.out.println("Has introducido el número 0. Programa finalizado.");
        
        sc.close();
    }
}
