package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio18 {
    public static void main(String[] args) {
        // 18. Leer números, permitiendo únicamente que el recién leído sea distinto de cero y mayor 
        // que el anterior. En caso contrario se debe detener el programa.
        // Igual que el 16, pero la condición de permanencia en el bucle debe incluir que “n” sea 
        // distinto de cero. Además, antes de entrar en el bucle se deberá comprobar que “n” sea 
        // distinto de cero con un “if”.

        Scanner sc = new Scanner(System.in);
        int ant, n;

        System.out.print("Introduce un número inicial (distinto de 0): ");
        n = sc.nextInt();

        if (n != 0) {
            ant = n;

            do {
                System.out.print("Introduce un número mayor que " + ant + " (0 para detener): ");
                n = sc.nextInt();

                if (n != 0 && n > ant) {
                    ant = n; // Actualizamos el valor anterior solo si se cumple la condición
                }
            } while (n != 0 && n > ant); // Permanece mientras n sea mayor que ant y distinto de 0
        }

        System.out.println("El número introducido no es válido (0 o menor o igual al anterior). Programa finalizado.");
        sc.close();
    }
}
