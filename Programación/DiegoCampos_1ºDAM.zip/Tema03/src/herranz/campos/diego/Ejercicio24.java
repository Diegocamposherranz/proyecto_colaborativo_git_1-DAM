package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio24 {
    public static void main(String[] args) {
        // 24. Indicar la suma de los dígitos de posición impar de un número dado.
        // Usar una variable booleana “impar” que alterna entre true y false en cada iteración.

        Scanner sc = new Scanner(System.in);
        System.out.print("Introduce un número entero: ");
        int n = sc.nextInt();

        int acc = 0;
        boolean impar = true;

        while (n > 0) {
            int cifra = n % 10;
            if (impar) acc += cifra;
            impar = !impar;
            n = n / 10;
        }

        System.out.println("La suma de los dígitos en posición impar es: " + acc);
        sc.close();
    }
}
