package herranz.campos.diego;
import java.util.Scanner;
public class Ejercicio11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/* Mostrar los números IMPARES que existan entre un número n1 (cota inferior) y otro 
		   número n2 (cota superior), pudiendo ser n1 y n2 cualquier número, siempre y cuando n1 
		   <= n2 (n1 y n2 deben leerse desde el teclado)*/
     Scanner scanner = new Scanner(System.in);
        
     int n1; // Cota inferior
     int n2; // Cota superior

     System.out.println("--- Buscador de Números Impares ---");

        // 1. Lectura de la cota inferior (n1)
     System.out.print("Introduce el número de inicio (n1, cota inferior): ");
        // Usamos nextInt() para leer el número entero.
     n1 = scanner.nextInt(); 

        // 2. Lectura de la cota superior (n2)
     System.out.print("Introduce el número final (n2, cota superior): ");
     n2 = scanner.nextInt();

        // Cerramos el scanner ya que hemos terminado de leer la entrada
     scanner.close(); 
        
        // 3. Verificación de la condición n1 <= n2
      if (n1 > n2) {
      System.out.println("\nERROR: La cota inferior (n1) debe ser menor o igual que la cota superior (n2).");
      return; // Termina la ejecución si hay un error
        }

      System.out.println("\nNúmeros IMPARES entre " + n1 + " y " + n2 + ":");
        
        // 4. Bucle para iterar de n1 a n2 (inclusive)
      for (int numero = n1; numero <= n2; numero++) {
            
            // 5. Verificación de Imparidad
            // Un número es IMPAR si su resto al dividirlo por 2 es 1 (o diferente de 0).
       if (numero % 2 != 0) {
                // Si es impar, lo mostramos
       System.out.println(numero);
            }
        }
    }

	}

