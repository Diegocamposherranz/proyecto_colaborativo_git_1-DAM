package herranz.campos.diego;

public class Ejercicio28 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Crear un método initDescubierto(): String[][] que cree un tablero de barcos enemigos
        // descubiertos “vacío” del juego de los barcos,
        // es decir, que en todas sus 10x10 casillas esté contenido un espacio “ ”.

        // Crear el tablero vacío de enemigos descubiertos
        String[][] tableroDescubierto = initDescubierto();

        // Mostrar el tablero generado
        mostrar(tableroDescubierto);
    }

    // Método que crea un tablero 10x10 lleno de espacios " "
    public static String[][] initDescubierto() {
        String[][] t = new String[10][10];

        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t[i].length; j++) {
                t[i][j] = " "; // inicializa todas las casillas con un espacio
            }
        }

        return t;
    }

    // Método auxiliar para mostrar el tablero con etiquetas (igual que en el ejercicio 26)
    public static void mostrar(String[][] t) {
        char[] letrasFilas = {'A','B','C','D','E','F','G','H','I','J'};

        System.out.println("=== Tablero Enemigo Descubierto ===\n");

        // Mostrar cabecera de columnas
        System.out.print("   ");
        for (int col = 1; col <= t[0].length; col++) {
            System.out.printf("%-3d", col);
        }
        System.out.println();

        // Mostrar filas
        for (int i = 0; i < t.length; i++) {
            System.out.print(letrasFilas[i] + "  ");
            for (int j = 0; j < t[i].length; j++) {
                System.out.print(t[i][j] + "  ");
            }
            System.out.println();
        }
    }
}