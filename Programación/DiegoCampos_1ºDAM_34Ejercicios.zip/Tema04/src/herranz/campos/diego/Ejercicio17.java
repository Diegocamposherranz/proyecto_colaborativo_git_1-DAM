package herranz.campos.diego;

public class Ejercicio17 {

    public static void main(String[] args) {
        // Igual que el ejercicio anterior pero para matrices de tamaño NxN.
        // Si no se pasan argumentos, se usan valores por defecto.

        int N;
        int[][] A;
        int[][] B;

        if (args.length < 1) {
            System.out.println("No se han introducido argumentos. Usando N = 3 y valores por defecto...\n");
            N = 3;
            int[] valoresPorDefecto = {
                1, 2, 3,
                4, 5, 6,
                7, 8, 9,
                9, 8, 7,
                6, 5, 4,
                3, 2, 1
            };

            A = new int[N][N];
            B = new int[N][N];

            int index = 0;
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    A[i][j] = valoresPorDefecto[index];
                    index++;
                }
            }
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    B[i][j] = valoresPorDefecto[index];
                    index++;
                }
            }

        } else {
            N = Integer.parseInt(args[0]);
            int totalValores = 2 * N * N;

            if (args.length != totalValores + 1) {
                System.out.println("Error: Debes introducir " + totalValores + " valores después de N.");
                return;
            }

            A = new int[N][N];
            B = new int[N][N];

            int index = 1;
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    A[i][j] = Integer.parseInt(args[index]);
                    index++;
                }
            }
            for (int i = 0; i < N; i++) {
                for (int j = 0; j < N; j++) {
                    B[i][j] = Integer.parseInt(args[index]);
                    index++;
                }
            }
        }

        int[][] suma = new int[N][N];
        int[][] producto = new int[N][N];

        // Calcular suma
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                suma[i][j] = A[i][j] + B[i][j];
            }
        }

        // Calcular producto
        for (int i = 0; i < N; i++) {
            for (int j = 0; j < N; j++) {
                producto[i][j] = 0;
                for (int k = 0; k < N; k++) {
                    producto[i][j] += A[i][k] * B[k][j];
                }
            }
        }

        // Mostrar resultados
        System.out.println("Matriz A:");
        mostrarMatriz(A);
        System.out.println("Matriz B:");
        mostrarMatriz(B);
        System.out.println("Suma de A + B:");
        mostrarMatriz(suma);
        System.out.println("Producto de A x B:");
        mostrarMatriz(producto);
    }

    // Método auxiliar para mostrar matrices
    public static void mostrarMatriz(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println();
    }
}