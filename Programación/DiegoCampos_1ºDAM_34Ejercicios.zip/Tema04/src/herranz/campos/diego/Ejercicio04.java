package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio04 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Este programa pide palabras hasta que se introduzca "FIN" (en mayúsculas)
        // o hasta un máximo de 30 palabras.
        // Luego forma una palabra secreta con la primera letra de cada palabra
        // (exceptuando "FIN").

        Scanner sc = new Scanner(System.in);
        String[] palabras = new String[30];
        int contador = 0;
        String palabra;

        System.out.println("Introduce palabras (FIN para terminar, máximo 30):");

        do {
            System.out.print("Palabra " + (contador + 1) + ": ");
            palabra = sc.next();

            if (!palabra.equals("FIN")) {
                palabras[contador] = palabra;
                contador++;
            }

        } while (!palabra.equals("FIN") && contador < 30);

        // Construir la palabra secreta
        StringBuilder palabraSecreta = new StringBuilder();
        for (int i = 0; i < contador; i++) {
            palabraSecreta.append(palabras[i].charAt(0));
        }

        System.out.println("Palabra secreta: " + palabraSecreta);

        sc.close();
    }
}