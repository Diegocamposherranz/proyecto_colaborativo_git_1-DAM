package herranz.campos.diego;

public class Ejercicio09 {

    public static void main(String[] args) {
        // Si no hay argumentos, se usan valores por defecto
        if (args.length == 0) {
            System.out.println("No se recibieron argumentos. Usando datos por defecto...\n");
            args = new String[] {"2", "Diego", "Campos", "Ana", "Perez"};
        }

        if (args.length < 3 || (args.length - 1) % 2 != 0) {
            System.out.println("Uso: java herranz.campos.diego.Ejercicio9 <numero_personas> <nombre1> <apellido1> <nombre2> <apellido2> ...");
            return;
        }

        int numPersonas = Integer.parseInt(args[0]);

        if (args.length != (numPersonas * 2) + 1) {
            System.out.println("Error: el número de nombres y apellidos no coincide con la cantidad indicada.");
            return;
        }

        Persona[] personas = new Persona[numPersonas];
        int indice = 1;

        for (int i = 0; i < numPersonas; i++) {
            String nombre = args[indice];
            String apellido = args[indice + 1];
            personas[i] = new Persona(nombre, apellido);
            indice += 2;
        }

        for (Persona p : personas) {
            p.saludar();
        }
    }
}

class Persona {
    private String nombre;
    private String apellido;

    public Persona(String nombre, String apellido) {
        this.nombre = nombre;
        this.apellido = apellido;
    }

    public void saludar() {
        System.out.println("Hola, soy " + nombre + " " + apellido);
    }
}
