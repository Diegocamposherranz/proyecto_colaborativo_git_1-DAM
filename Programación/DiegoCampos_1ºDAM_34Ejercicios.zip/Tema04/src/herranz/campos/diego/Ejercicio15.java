package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio15 {

    public static void main(String[] args) {
        int[][] matriz = new int[3][3];
        int[] datos = new int[9];

        // Si no hay 9 argumentos, pedirlos o usar valores por defecto
        if (args.length != 9) {
            System.out.println("No se recibieron 9 argumentos. Usando valores por defecto...\n");

            Scanner sc = new Scanner(System.in);
            System.out.print("Introduce 9 números separados por espacios (o presiona Enter para usar 1 2 3 4 5 6 7 8 9): ");
            String linea = sc.nextLine().trim();

            if (linea.isEmpty()) {
                linea = "1 2 3 4 5 6 7 8 9"; // valores por defecto
            }

            String[] partes = linea.split("\\s+");
            if (partes.length != 9) {
                System.out.println("Error: Debes introducir exactamente 9 números.");
                sc.close();
                return;
            }

            for (int i = 0; i < 9; i++) {
                datos[i] = Integer.parseInt(partes[i]);
            }

            sc.close();
        } else {
            // Si hay 9 argumentos, los convertimos directamente
            for (int i = 0; i < 9; i++) {
                datos[i] = Integer.parseInt(args[i]);
            }
        }

        // Rellenar la matriz 3x3
        int indice = 0;
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                matriz[i][j] = datos[indice++];
            }
        }

        // Mostrar la matriz
        System.out.println("\nMatriz 3x3 introducida:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(matriz[i][j] + "\t");
            }
            System.out.println();
        }
    }
}