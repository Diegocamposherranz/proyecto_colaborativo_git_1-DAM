package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio30 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Crear un programa que le pida al usuario un string de este tipo:
        // <letra> <num> <HV> (p.ej. A 7 H)
        // y ubique en un tablero en blanco “t” en dicha posición un barco de tamaño 2.
        // El programa deberá mostrar la situación actual de dicho tablero.

        Scanner sc = new Scanner(System.in);

        // Crear tablero vacío
        String[][] tablero = init();

        // Pedir datos al usuario
        System.out.println("Introduce la posición y orientación del barco (ejemplo: A 7 H): ");
        String fila = sc.next();     // letra de la fila
        String columna = sc.next();  // número de la columna
        String hv = sc.next();       // orientación H o V

        // Intentar ubicar barco de tamaño 2
        int resultado = ubicar(tablero, fila, columna, hv, 2);

        // Mostrar resultado
        switch (resultado) {
            case 0:
                System.out.println("\n✅ Barco colocado correctamente.");
                break;
            case -1:
                System.out.println("\n❌ Error: el barco se sale de los límites del tablero.");
                break;
            case -2:
                System.out.println("\n⚠️ Error: el barco está adyacente a otro.");
                break;
            default:
                System.out.println("\n❗ Error desconocido al colocar el barco.");
                break;
        }

        // Mostrar tablero actualizado
        mostrar(tablero);

        sc.close();
    }

    // Crea un tablero vacío (10x10) con puntos
    public static String[][] init() {
        String[][] t = new String[10][10];
        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t[i].length; j++) {
                t[i][j] = ".";
            }
        }
        return t;
    }

    // Coloca un barco en el tablero según las coordenadas y orientación
    public static int ubicar(String[][] t, String fila, String columna, String hv, int tam) {
        try {
            int filaNum = fila.toUpperCase().charAt(0) - 'A';
            int colNum = Integer.parseInt(columna) - 1;

            // Comprobaciones de límites
            if (filaNum < 0 || filaNum >= 10 || colNum < 0 || colNum >= 10) return -1;
            if (tam < 2 || tam > 4) return -3;
            if (hv.equalsIgnoreCase("H") && colNum + tam > 10) return -1;
            if (hv.equalsIgnoreCase("V") && filaNum + tam > 10) return -1;

            // Comprobar adyacencias (para evitar barcos pegados)
            for (int i = 0; i < tam; i++) {
                int f = filaNum + (hv.equalsIgnoreCase("V") ? i : 0);
                int c = colNum + (hv.equalsIgnoreCase("H") ? i : 0);
                for (int df = -1; df <= 1; df++) {
                    for (int dc = -1; dc <= 1; dc++) {
                        int nf = f + df;
                        int nc = c + dc;
                        if (nf >= 0 && nf < 10 && nc >= 0 && nc < 10) {
                            if (t[nf][nc].equals("O")) return -2;
                        }
                    }
                }
            }

            // Colocar barco
            for (int i = 0; i < tam; i++) {
                int f = filaNum + (hv.equalsIgnoreCase("V") ? i : 0);
                int c = colNum + (hv.equalsIgnoreCase("H") ? i : 0);
                t[f][c] = "O";
            }

            return 0; // correcto
        } catch (Exception e) {
            return -3; // error genérico
        }
    }

    // Muestra el tablero con etiquetas
    public static void mostrar(String[][] t) {
        char[] letrasFilas = {'A','B','C','D','E','F','G','H','I','J'};

        System.out.println("\n=== Tablero Actual ===\n");
        System.out.print("   ");
        for (int col = 1; col <= 10; col++) {
            System.out.printf("%-3d", col);
        }
        System.out.println();

        for (int i = 0; i < 10; i++) {
            System.out.print(letrasFilas[i] + "  ");
            for (int j = 0; j < 10; j++) {
                System.out.print(t[i][j] + "  ");
            }
            System.out.println();
        }
    }
}