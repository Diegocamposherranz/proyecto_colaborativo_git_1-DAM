package herranz.campos.diego;

public class Ejercicio21 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Rehacer el ejercicio anterior de forma que se muestre el contenido de todas las filas,
        // pero asumiendo que la primera fila contiene los nombres de las columnas (en mayúsculas).
        // Dibujar un separador entre el nombre de las columnas y el contenido de las filas.

        // Datos: la primera fila son los nombres de las columnas
        String[][] datos = {
            {"DNI", "NOMBRE", "APELLIDO"},
            {"1", "Pepe", "Sánchez"},
            {"2", "Ana", "García"},
            {"3", "Juan", "Palomo"}
        };

        // Mostrar toda la tabla con separador
        mostrarTabla(datos);
    }

    // Método que imprime toda la tabla con formato
    public static void mostrarTabla(String[][] datos) {
        // Mostrar encabezados (primera fila)
        for (int i = 0; i < datos[0].length; i++) {
            System.out.print(datos[0][i] + "\t");
        }
        System.out.println();

        // Dibujar línea separadora
        for (int i = 0; i < datos[0].length; i++) {
            System.out.print("--------");
        }
        System.out.println();

        // Mostrar el resto de filas (los datos)
        for (int i = 1; i < datos.length; i++) {
            for (int j = 0; j < datos[i].length; j++) {
                System.out.print(datos[i][j] + "\t");
            }
            System.out.println();
        }
    }
}