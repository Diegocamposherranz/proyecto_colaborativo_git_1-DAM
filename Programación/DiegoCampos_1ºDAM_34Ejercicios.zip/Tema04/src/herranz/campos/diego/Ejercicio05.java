package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio05 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Este programa pide al usuario que introduzca varios números enteros.
        // Luego muestra únicamente los elementos que están en posiciones (índices) impares del array.

        Scanner sc = new Scanner(System.in);

        System.out.print("¿Cuántos números quieres introducir? (máximo 30): ");
        int n = sc.nextInt();

        if (n > 30) n = 30; // limitar tamaño máximo

        int[] numeros = new int[n];

        // Lectura de los valores
        for (int i = 0; i < n; i++) {
            System.out.print("Número " + (i + 1) + ": ");
            numeros[i] = sc.nextInt();
        }

        // Mostrar solo los elementos en índices impares
        System.out.println("\nElementos con índices impares:");
        for (int i = 0; i < n; i++) {
            if (i % 2 != 0) { // índice impar
                System.out.println("Índice " + i + ": " + numeros[i]);
            }
        }

        sc.close();
    }
}