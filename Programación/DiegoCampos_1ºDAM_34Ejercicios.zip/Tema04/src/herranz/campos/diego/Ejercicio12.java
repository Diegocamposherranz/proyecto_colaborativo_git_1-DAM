package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio12 {

    public static void main(String[] args) {
        int[] numeros;

        if (args.length == 0) {
            System.out.println("No se recibieron argumentos. Usando valores por defecto...\n");
            Scanner sc = new Scanner(System.in);

            System.out.print("Introduce una lista de números separados por espacios (o presiona Enter para usar 5 3 2 8 1): ");
            String linea = sc.nextLine().trim();

            if (linea.isEmpty()) {
                linea = "5 3 2 8 1";
            }

            String[] partes = linea.split("\\s+");
            numeros = new int[partes.length];
            for (int i = 0; i < partes.length; i++) {
                numeros[i] = Integer.parseInt(partes[i]);
            }

            sc.close();
        } else {
            numeros = new int[args.length];
            for (int i = 0; i < args.length; i++) {
                numeros[i] = Integer.parseInt(args[i]);
            }
        }

        // Aquí usamos el nombre completo: java.util.Arrays
        System.out.println("Array original: " + java.util.Arrays.toString(numeros));

        int[] ordenado = Ejercicio11.burbuja(numeros);

        System.out.println("Array ordenado: " + java.util.Arrays.toString(ordenado));
    }
}
