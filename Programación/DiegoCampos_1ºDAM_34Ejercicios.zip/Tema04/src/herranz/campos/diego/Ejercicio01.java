package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio01 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Este programa pide hasta 30 números enteros (o hasta que se introduzca 0).
        // Después muestra todos los números introducidos, separados por comas.
        // El 0 no se muestra en la lista final.

        Scanner sc = new Scanner(System.in);
        int[] numeros = new int[30]; // máximo 30 números
        int contador = 0;
        int num;

        System.out.println("Introduce números enteros (0 para terminar, máximo 30):");

        // Lectura de números
        do {
            System.out.print("Número " + (contador + 1) + ": ");
            num = sc.nextInt();

            if (num != 0) {
                numeros[contador] = num;
                contador++;
            }

        } while (num != 0 && contador < 30);

        // Mostrar resultados
        System.out.print("\nNúmeros introducidos: ");
        for (int i = 0; i < contador; i++) {
            System.out.print(numeros[i]);
            if (i < contador - 1) {
                System.out.print(", ");
            }
        }

        System.out.println("\nPrograma finalizado.");
        sc.close();
    }
}
