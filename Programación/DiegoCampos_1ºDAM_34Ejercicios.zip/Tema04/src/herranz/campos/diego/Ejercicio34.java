package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio34 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("=== BATALLA NAVAL ===");

        // Tableros de los dos jugadores
        String[][] tableroJ1 = init();
        String[][] tableroJ2 = init();
        String[][] descubiertoJ1 = initDescubierto();
        String[][] descubiertoJ2 = initDescubierto();

        // Colocación de barcos
        System.out.println("\nJugador 1: coloca tus barcos");
        colocarBarcos(sc, tableroJ1);

        System.out.println("\nJugador 2: coloca tus barcos");
        colocarBarcos(sc, tableroJ2);

        boolean fin = false;
        int turno = 1;

        while (!fin) {
            System.out.println("\n==============================");
            System.out.println("TURNO DEL JUGADOR " + turno);
            System.out.println("==============================");

            String[][] enemigo = (turno == 1) ? tableroJ2 : tableroJ1;
            String[][] descubierto = (turno == 1) ? descubiertoJ1 : descubiertoJ2;

            for (int d = 1; d <= 3; d++) {
                System.out.println("\nDisparo " + d + " de 3");
                mostrar(descubierto);

                System.out.print("Introduce coordenadas (ej: B 4): ");
                String fila = sc.next().toUpperCase();
                String col = sc.next();

                int res = disparo(enemigo, descubierto, fila, col);

                switch (res) {
                    case 1:
                        System.out.println("🎯 ¡Impacto!");
                        break;
                    case 2:
                        System.out.println("💥 ¡Hundido!");
                        break;
                    case 0:
                        System.out.println("🌊 Agua...");
                        break;
                    case -1:
                        System.out.println("⚠️ Ya habías disparado ahí.");
                        d--; // repetir disparo
                        break;
                    default:
                        System.out.println("❌ Coordenadas inválidas.");
                        d--; // repetir disparo
                        break;
                }

                mostrar(descubierto);

                if (todosHundidos(enemigo)) {
                    System.out.println("\n🏆 ¡Jugador " + turno + " ha ganado! 🏆");
                    fin = true;
                    break;
                }
            }

            if (!fin) turno = (turno == 1) ? 2 : 1;
        }

        sc.close();
    }
    // INICIALIZAR TABLEROS
    public static String[][] init() {
        String[][] t = new String[10][10];
        for (int i = 0; i < 10; i++)
            for (int j = 0; j < 10; j++)
                t[i][j] = ".";
        return t;
    }

    public static String[][] initDescubierto() {
        String[][] t = new String[10][10];
        for (int i = 0; i < 10; i++)
            for (int j = 0; j < 10; j++)
                t[i][j] = " ";
        return t;
    }
    // MOSTRAR TABLERO
    public static void mostrar(String[][] t) {
        char[] letras = {'A','B','C','D','E','F','G','H','I','J'};

        System.out.print("   ");
        for (int c = 1; c <= 10; c++) System.out.printf("%-3d", c);
        System.out.println();

        for (int i = 0; i < 10; i++) {
            System.out.print(letras[i] + "  ");
            for (int j = 0; j < 10; j++)
                System.out.print(t[i][j] + "  ");
            System.out.println();
        }
    }

    // COLOCAR BARCOS
    public static void colocarBarcos(Scanner sc, String[][] tablero) {
        int[] tamanos = {2, 2, 3, 3, 4};

        for (int tam : tamanos) {
            boolean colocado = false;
            while (!colocado) {
                System.out.print("Coloca barco de tamaño " + tam + " (ej: A 5 H): ");
                String fila = sc.next().toUpperCase();
                String col = sc.next();
                String hv = sc.next().toUpperCase();

                int res = ubicar(tablero, fila, col, hv, tam);
                if (res == 0) {
                    mostrar(tablero);
                    colocado = true;
                } else if (res == -1)
                    System.out.println("❌ Se sale del tablero.");
                else if (res == -2)
                    System.out.println("⚠️ Está adyacente a otro barco.");
                else
                    System.out.println("❗ Error en la colocación.");
            }
        }
    }

    // UBICAR BARCO
    public static int ubicar(String[][] t, String fila, String columna, String hv, int tam) {
        try {
            int filaNum = fila.charAt(0) - 'A';
            int colNum = Integer.parseInt(columna) - 1;

            if (filaNum < 0 || filaNum >= 10 || colNum < 0 || colNum >= 10) return -1;
            if (hv.equals("H") && colNum + tam > 10) return -1;
            if (hv.equals("V") && filaNum + tam > 10) return -1;

            // adyacencia
            for (int i = 0; i < tam; i++) {
                int f = filaNum + (hv.equals("V") ? i : 0);
                int c = colNum + (hv.equals("H") ? i : 0);
                for (int df = -1; df <= 1; df++)
                    for (int dc = -1; dc <= 1; dc++) {
                        int nf = f + df, nc = c + dc;
                        if (nf >= 0 && nf < 10 && nc >= 0 && nc < 10)
                            if (t[nf][nc].equals("O")) return -2;
                    }
            }

            for (int i = 0; i < tam; i++) {
                int f = filaNum + (hv.equals("V") ? i : 0);
                int c = colNum + (hv.equals("H") ? i : 0);
                t[f][c] = "O";
            }

            return 0;
        } catch (Exception e) {
            return -3;
        }
    }

    // DISPARO
    public static int disparo(String[][] tPropio, String[][] tDescubierto, String fila, String columna) {
        try {
            int filaNum = fila.charAt(0) - 'A';
            int colNum = Integer.parseInt(columna) - 1;

            if (filaNum < 0 || filaNum >= 10 || colNum < 0 || colNum >= 10)
                return -2;

            String valor = tPropio[filaNum][colNum];

            if (valor.equals("X") || valor.equals("*")) return -1;

            if (valor.equals(".")) {
                tPropio[filaNum][colNum] = "*";
                tDescubierto[filaNum][colNum] = "*";
                return 0;
            }

            if (valor.equals("O")) {
                tPropio[filaNum][colNum] = "X";
                tDescubierto[filaNum][colNum] = "X";
                if (hundido(tPropio)) return 2;
                return 1;
            }

            return -2;
        } catch (Exception e) {
            return -2;
        }
    }

    // VERIFICAR SI TODOS LOS BARCOS HUNDIDOS
    public static boolean todosHundidos(String[][] t) {
        for (int i = 0; i < 10; i++)
            for (int j = 0; j < 10; j++)
                if (t[i][j].equals("O")) return false;
        return true;
    }

    // COMPROBAR SI QUEDAN BARCOS
    private static boolean hundido(String[][] t) {
        for (int i = 0; i < 10; i++)
            for (int j = 0; j < 10; j++)
                if (t[i][j].equals("O")) return false;
        return true;
    }
}
