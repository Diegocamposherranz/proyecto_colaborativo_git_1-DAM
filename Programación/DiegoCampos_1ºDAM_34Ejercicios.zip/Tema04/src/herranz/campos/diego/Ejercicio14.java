package herranz.campos.diego;

public class Ejercicio14 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
    	// Dadas dos matrices de 3x3 “a” y “b” mostrar su contenido y el contenido de la matriz 
    	// resultante de multiplicar ambas matrices.

        // Definimos dos matrices de 3x3 (a y b)
        int[][] a = {
            {1, 2, 3},
            {4, 5, 6},
            {7, 8, 9}
        };

        int[][] b = {
            {9, 8, 7},
            {6, 5, 4},
            {3, 2, 1}
        };

        // Creamos una matriz c para guardar el resultado
        int[][] c = new int[3][3];

        // Multiplicación de matrices
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                c[i][j] = 0; // Inicializamos en 0 antes de sumar
                for (int k = 0; k < 3; k++) {
                    c[i][j] += a[i][k] * b[k][j];
                }
            }
        }

        // Mostrar matriz A
        System.out.println("Matriz A:");
        mostrarMatriz(a);

        // Mostrar matriz B
        System.out.println("Matriz B:");
        mostrarMatriz(b);

        // Mostrar resultado (matriz C)
        System.out.println("Matriz resultante C = A x B:");
        mostrarMatriz(c);
    }

    // Mostrar matrices en consola
    public static void mostrarMatriz(int[][] matriz) {
        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {
                System.out.print(matriz[i][j] + "\t"); // Tabulador para mejor formato
            }
            System.out.println();
        }
        System.out.println(); // Línea en blanco entre matrices
    }
}
