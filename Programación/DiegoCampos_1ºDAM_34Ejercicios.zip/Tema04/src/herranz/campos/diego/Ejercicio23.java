package herranz.campos.diego;

import java.util.Arrays;

public class Ejercicio23 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Crear un método mezclar(a: int[], b: int[], modo: String): int[] que, dados dos arrays a y b,
        // de tamaño indeterminado, mezcle su contenido y devuelva dicho contenido mezclado.
        // El modo en el que han de mezclarse ambos arrays se decidirá en función del contenido
        // de la variable “modo”, y pueden ser los siguientes:
        // “delanteA”, “delanteB”, “cremalleraA”, “cremalleraB”.
        // Los modos “delanteA” y “delanteB” concatenan ambos arrays en distinto orden.
        // Los modos “cremalleraA” y “cremalleraB” alternan los elementos de a y b,
        // comenzando por a o b respectivamente.
        // NOTA: Para primeras pruebas, asúmase que los arrays a y b son del mismo tamaño,
        // pero el algoritmo debe funcionar también para tamaños diferentes.

        int[] a = {1, 3, 5, 7};
        int[] b = {2, 4, 6, 8, 10};

        System.out.println("Modo delanteA: " + Arrays.toString(mezclar(a, b, "delanteA")));
        System.out.println("Modo delanteB: " + Arrays.toString(mezclar(a, b, "delanteB")));
        System.out.println("Modo cremalleraA: " + Arrays.toString(mezclar(a, b, "cremalleraA")));
        System.out.println("Modo cremalleraB: " + Arrays.toString(mezclar(a, b, "cremalleraB")));
    }

    public static int[] mezclar(int[] a, int[] b, String modo) {
        int[] resultado = new int[a.length + b.length];
        int index = 0;

        switch (modo) {
            case "delanteA":
                // Primero todos los elementos de 'a', luego los de 'b'
                for (int i = 0; i < a.length; i++) resultado[index++] = a[i];
                for (int i = 0; i < b.length; i++) resultado[index++] = b[i];
                break;

            case "delanteB":
                // Primero todos los elementos de 'b', luego los de 'a'
                for (int i = 0; i < b.length; i++) resultado[index++] = b[i];
                for (int i = 0; i < a.length; i++) resultado[index++] = a[i];
                break;

            case "cremalleraA":
            case "cremalleraB":
                boolean turnoA = modo.equals("cremalleraA"); // comienza A si el modo es cremalleraA
                int i = 0, j = 0;
                while (i < a.length || j < b.length) {
                    if (turnoA && i < a.length) {
                        resultado[index++] = a[i++];
                    } else if (!turnoA && j < b.length) {
                        resultado[index++] = b[j++];
                    }
                    turnoA = !turnoA; // alterna turno
                }
                break;

            default:
                System.out.println("Modo no válido. Usa: delanteA, delanteB, cremalleraA, cremalleraB");
                return new int[0];
        }

        return resultado;
    }
}