package herranz.campos.diego;

import java.util.Random;
import java.util.Scanner;

public class Ejercicio10 {

    public static void main(String[] args) {
        int nTiradas;
        int nCaras;

        // Si no se pasan argumentos, se piden por teclado o se usan valores por defecto
        if (args.length != 2) {
            System.out.println("No se recibieron argumentos. Usando valores por defecto...\n");

            Scanner sc = new Scanner(System.in);

            System.out.print("Introduce el número de tiradas (por defecto 10): ");
            String tiradasInput = sc.nextLine().trim();
            nTiradas = tiradasInput.isEmpty() ? 10 : Integer.parseInt(tiradasInput);

            System.out.print("Introduce el número de caras del dado (por defecto 6): ");
            String carasInput = sc.nextLine().trim();
            nCaras = carasInput.isEmpty() ? 6 : Integer.parseInt(carasInput);

            sc.close();
        } else {
            // Si hay argumentos, los usamos
            nTiradas = Integer.parseInt(args[0]);
            nCaras = Integer.parseInt(args[1]);
        }

        if (nTiradas <= 0 || nCaras <= 0) {
            System.out.println("Error: los valores deben ser mayores que cero.");
            return;
        }

        int[] contador = new int[nCaras];
        Random rand = new Random();

        for (int i = 0; i < nTiradas; i++) {
            int resultado = rand.nextInt(nCaras) + 1;
            contador[resultado - 1]++;
        }

        System.out.println("\nResultados de " + nTiradas + " tiradas de un dado de " + nCaras + " caras:");
        for (int i = 0; i < nCaras; i++) {
            double porcentaje = (contador[i] * 100.0) / nTiradas;
            System.out.printf("Cara %d: %d veces (%.2f%%)%n", i + 1, contador[i], porcentaje);
        }
    }
}
