package herranz.campos.diego;

public class Ejercicio25 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Crear un método mostrar(t: String[][]) que muestre el contenido del array “t” por pantalla.
        // El array representará un tablero del juego "Hundir la flota", usando los caracteres:
        // "." (agua), "O" (barco), "X" (barco dañado) y " " (espacio desconocido).
        // El método debe recorrer la matriz y mostrar su contenido de forma ordenada.

        String[][] t = {
            {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
            {".", "O", "O", ".", ".", " ", " ", " ", " ", " "},
            {".", ".", " ", " ", " ", " ", " ", " ", " ", " "},
            {".", ".", ".", ".", ".", ".", "O", ".", ".", "."},
            {".", ".", " ", " ", " ", " ", " ", " ", " ", " "},
            {".", "O", ".", ".", ".", " ", " ", " ", " ", " "},
            {".", ".", ".", ".", ".", ".", "O", ".", ".", "."},
            {".", ".", ".", ".", ".", ".", "X", ".", ".", "."},
            {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
            {".", ".", ".", ".", "X", "X", ".", ".", ".", "."}
        };

        // Mostrar el tablero usando el método
        mostrar(t);
    }

    // Método que muestra por pantalla el contenido de la matriz t
    public static void mostrar(String[][] t) {
        System.out.println("=== Tablero de Hundir la Flota ===");
        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t[i].length; j++) {
                System.out.print(t[i][j] + "  "); // Dos espacios para mejorar la legibilidad
            }
            System.out.println(); // Salto de línea al terminar cada fila
        }
    }
}