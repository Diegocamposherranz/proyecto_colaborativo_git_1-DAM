package herranz.campos.diego;

public class Ejercicio33 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        // Ejercicio 33:
        // Crear un método disparo(tPropio, tDescubierto, fila, columna)
        // que simule un disparo a un tablero del jugador contrario y actualice ambos tableros.
        // Devuelve:
        // 1 → acierto a un barco
        // 2 → acierto y barco hundido
        // 0 → agua
        // -1 → ya se había disparado antes
        // -2 → error (coordenadas inválidas)

        // Tableros de prueba
        String[][] tableroEnemigo = {
                {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
                {".", ".", "O", "O", ".", ".", ".", ".", ".", "."},
                {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
                {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
                {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
                {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
                {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
                {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
                {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
                {".", ".", ".", ".", ".", ".", ".", ".", ".", "."}
        };

        String[][] tableroDescubierto = initDescubierto();

        // Ejemplos de disparo
        System.out.println(disparo(tableroEnemigo, tableroDescubierto, "B", "3")); // Acierta (1)
        System.out.println(disparo(tableroEnemigo, tableroDescubierto, "B", "4")); // Hundido (2)
        System.out.println(disparo(tableroEnemigo, tableroDescubierto, "C", "1")); // Agua (0)
        System.out.println(disparo(tableroEnemigo, tableroDescubierto, "C", "1")); // Repetido (-1)

        // Mostrar resultado de tablero descubierto
        System.out.println("\n=== TABLERO DESCUBIERTO ===");
        mostrar(tableroDescubierto);
    }

    // =============================
    // MÉTODOS AUXILIARES
    // =============================

    // Método que simula un disparo
    public static int disparo(String[][] tPropio, String[][] tDescubierto, String fila, String columna) {
        try {
            int filaNum = fila.toUpperCase().charAt(0) - 'A';
            int colNum = Integer.parseInt(columna) - 1;

            // Validar coordenadas
            if (filaNum < 0 || filaNum >= 10 || colNum < 0 || colNum >= 10)
                return -2;

            String valor = tPropio[filaNum][colNum];

            // Ya se había disparado
            if (valor.equals("X") || valor.equals("*"))
                return -1;

            // Agua
            if (valor.equals(".")) {
                tPropio[filaNum][colNum] = "*"; // marca como agua disparada
                tDescubierto[filaNum][colNum] = "*";
                return 0;
            }

            // Acierto en barco
            if (valor.equals("O")) {
                tPropio[filaNum][colNum] = "X"; // barco dañado
                tDescubierto[filaNum][colNum] = "X";

                // Comprobar si el barco ha sido hundido
                if (hundido(tPropio, filaNum, colNum)) {
                    return 2;
                }
                return 1;
            }

            return -2; // En caso de error inesperado
        } catch (Exception e) {
            return -2;
        }
    }

    // Comprueba si un barco ha sido completamente hundido
    private static boolean hundido(String[][] t, int fila, int col) {
        // Busca en las 4 direcciones si hay más partes de barco no dañadas conectadas
        int[][] direcciones = {{1,0}, {-1,0}, {0,1}, {0,-1}};

        for (int[] d : direcciones) {
            int f = fila;
            int c = col;

            while (true) {
                f += d[0];
                c += d[1];
                if (f < 0 || f >= 10 || c < 0 || c >= 10) break;
                if (t[f][c].equals("O")) return false; // aún hay parte no dañada
                if (t[f][c].equals(".")) break; // agua, se termina el barco
            }
        }
        return true;
    }

    // Crea un tablero descubierto (espacios vacíos)
    public static String[][] initDescubierto() {
        String[][] t = new String[10][10];
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                t[i][j] = " ";
            }
        }
        return t;
    }

    // Muestra un tablero
    public static void mostrar(String[][] t) {
        char[] letrasFilas = {'A','B','C','D','E','F','G','H','I','J'};

        System.out.println("   1  2  3  4  5  6  7  8  9 10");
        for (int i = 0; i < 10; i++) {
            System.out.print(letrasFilas[i] + "  ");
            for (int j = 0; j < 10; j++) {
                System.out.print(t[i][j] + "  ");
            }
            System.out.println();
        }
    }
}