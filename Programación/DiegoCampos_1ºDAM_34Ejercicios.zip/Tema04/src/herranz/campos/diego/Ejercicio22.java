package herranz.campos.diego;

public class Ejercicio22 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Rehacer el ejercicio 20 asumiendo los nombres de columna proporcionados
        // según las características del ejercicio 21.
        // Escoger el carácter * para ver todas las columnas.

        // Datos: la primera fila contiene los nombres de las columnas
        String[][] datos = {
            {"DNI", "NOMBRE", "APELLIDO"},
            {"1", "Pepe", "Sánchez"},
            {"2", "Ana", "García"},
            {"3", "Juan", "Palomo"}
        };

        // Si no se pasa argumento, se muestra la ayuda
        if (args.length == 0) {
            System.out.println("Uso: java herranz.campos.diego.Ejercicio22 <columna>");
            System.out.println("Ejemplo: dni | nombre | apellido | * (para ver todas las columnas)");
            return;
        }

        String columna = args[0].toUpperCase(); // Convertimos a mayúsculas para comparar con la cabecera
        System.out.println(mostrarColumna(datos, columna));
    }

    // Método que genera el texto a mostrar según la columna solicitada
    public static String mostrarColumna(String[][] datos, String columna) {
        StringBuilder sb = new StringBuilder();

        // Si el usuario quiere ver todas las columnas (*)
        if (columna.equals("*")) {
            // Mostrar encabezados
            for (int j = 0; j < datos[0].length; j++) {
                sb.append(datos[0][j]).append("\t");
            }
            sb.append("\n");

            // Separador
            for (int j = 0; j < datos[0].length; j++) {
                sb.append("--------");
            }
            sb.append("\n");

            // Mostrar todos los datos
            for (int i = 1; i < datos.length; i++) {
                for (int j = 0; j < datos[i].length; j++) {
                    sb.append(datos[i][j]).append("\t");
                }
                sb.append("\n");
            }
            return sb.toString();
        }

        // Si se pide una sola columna, buscamos su índice en la cabecera
        int indice = -1;
        for (int j = 0; j < datos[0].length; j++) {
            if (datos[0][j].equals(columna)) {
                indice = j;
                break;
            }
        }

        // Si no se encuentra la columna
        if (indice == -1) {
            return "Columna no válida. Usa: DNI | NOMBRE | APELLIDO | *";
        }

        // Mostrar solo esa columna
        sb.append(datos[0][indice]).append("\n");
        sb.append("--------\n");

        for (int i = 1; i < datos.length; i++) {
            sb.append(datos[i][indice]).append("\n");
        }

        return sb.toString();
    }
}