package herranz.campos.diego;

public class Ejercicio26 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Mejorar el método anterior para que se etiqueten las columnas del número 1 hasta el 10,
        // y las filas desde la letra “A” hasta la “J”.
        // El resultado debe tener el formato:
        //   1 2 3 4 5 6 7 8 9 10
        // A .  .  .  .  .  .  .  .  .  .
        // B .  O  O  .  .  .  .  .  .  .
        // ...
        // J .  .  .  .  .  .  .  .  .  .

        String[][] t = {
            {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
            {".", "O", "O", ".", ".", ".", ".", ".", ".", "."},
            {".", ".", ".", ".", ".", ".", "O", ".", ".", "."},
            {".", ".", ".", ".", ".", ".", "O", ".", ".", "."},
            {".", ".", ".", ".", ".", ".", "O", ".", ".", "."},
            {".", ".", ".", ".", ".", ".", "X", ".", ".", "."},
            {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
            {".", ".", ".", ".", "X", "X", ".", ".", ".", "."},
            {".", ".", ".", ".", ".", ".", ".", ".", ".", "."},
            {".", ".", ".", ".", ".", ".", ".", ".", ".", "."}
        };

        mostrar(t);
    }

    // Método que muestra el tablero con etiquetas de filas y columnas
    public static void mostrar(String[][] t) {
        char[] letrasFilas = {'A','B','C','D','E','F','G','H','I','J'};

        System.out.println("=== Tablero de Hundir la Flota ===\n");

        // Mostrar cabecera de columnas
        System.out.print("   "); // espacio antes del 1
        for (int col = 1; col <= t[0].length; col++) {
            System.out.printf("%-3d", col); // números alineados
        }
        System.out.println();

        // Mostrar filas con su letra y contenido
        for (int i = 0; i < t.length; i++) {
            System.out.print(letrasFilas[i] + "  "); // etiqueta de fila
            for (int j = 0; j < t[i].length; j++) {
                System.out.print(t[i][j] + "  ");
            }
            System.out.println();
        }
    }
}