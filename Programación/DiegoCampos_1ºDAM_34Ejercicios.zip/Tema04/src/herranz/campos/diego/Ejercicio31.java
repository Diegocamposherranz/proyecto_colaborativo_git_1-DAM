package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio31 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        // Ejercicio 31:
        // Mejorar el programa anterior para que permita ubicar:
        // - 2 barcos de tamaño 2
        // - 2 barcos de tamaño 3
        // - 1 barco de tamaño 4
        // Cada barco se ubicará pidiendo al usuario <letra> <número> <HV>
        // y mostrando el tablero después de cada colocación.

        Scanner sc = new Scanner(System.in);
        String[][] tablero = init();

        int[] tamanios = {2, 2, 3, 3, 4};
        int numBarco = 1;

        for (int tam : tamanios) {
            boolean colocado = false;
            while (!colocado) {
                System.out.println("\nColoca el barco #" + numBarco + " de tamaño " + tam);
                System.out.print("Introduce <letra> <número> <H/V> (ej: B 5 H): ");
                
                String fila = sc.next();
                String columna = sc.next();
                String hv = sc.next();

                int resultado = ubicar(tablero, fila, columna, hv, tam);

                switch (resultado) {
                    case 0:
                        System.out.println("✅ Barco colocado correctamente.");
                        colocado = true;
                        break;
                    case -1:
                        System.out.println("❌ Error: el barco se sale de los límites del tablero.");
                        break;
                    case -2:
                        System.out.println("⚠️ Error: el barco está adyacente o sobre otro.");
                        break;
                    default:
                        System.out.println("❗ Error desconocido al colocar el barco.");
                        break;
                }
                mostrar(tablero);
            }
            numBarco++;
        }

        System.out.println("\n🚢 Todos los barcos han sido colocados correctamente.");
        sc.close();
    }

    // === Métodos auxiliares ===

    // Inicializa un tablero vacío (10x10)
    public static String[][] init() {
        String[][] t = new String[10][10];
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                t[i][j] = ".";
            }
        }
        return t;
    }

    // Coloca un barco de tamaño "tam" en el tablero
    public static int ubicar(String[][] t, String fila, String columna, String hv, int tam) {
        try {
            int filaNum = fila.toUpperCase().charAt(0) - 'A';
            int colNum = Integer.parseInt(columna) - 1;

            // Validaciones de límites
            if (filaNum < 0 || filaNum >= 10 || colNum < 0 || colNum >= 10) return -1;
            if (tam < 2 || tam > 4) return -3;
            if (hv.equalsIgnoreCase("H") && colNum + tam > 10) return -1;
            if (hv.equalsIgnoreCase("V") && filaNum + tam > 10) return -1;

            // Comprobar adyacencias
            for (int i = 0; i < tam; i++) {
                int f = filaNum + (hv.equalsIgnoreCase("V") ? i : 0);
                int c = colNum + (hv.equalsIgnoreCase("H") ? i : 0);
                for (int df = -1; df <= 1; df++) {
                    for (int dc = -1; dc <= 1; dc++) {
                        int nf = f + df;
                        int nc = c + dc;
                        if (nf >= 0 && nf < 10 && nc >= 0 && nc < 10) {
                            if (t[nf][nc].equals("O")) return -2;
                        }
                    }
                }
            }

            // Colocar barco
            for (int i = 0; i < tam; i++) {
                int f = filaNum + (hv.equalsIgnoreCase("V") ? i : 0);
                int c = colNum + (hv.equalsIgnoreCase("H") ? i : 0);
                t[f][c] = "O";
            }

            return 0;
        } catch (Exception e) {
            return -3;
        }
    }

    // Muestra el tablero con etiquetas
    public static void mostrar(String[][] t) {
        char[] letrasFilas = {'A','B','C','D','E','F','G','H','I','J'};
        System.out.println("\n=== Tablero Actual ===\n");
        System.out.print("   ");
        for (int col = 1; col <= 10; col++) {
            System.out.printf("%-3d", col);
        }
        System.out.println();
        for (int i = 0; i < 10; i++) {
            System.out.print(letrasFilas[i] + "  ");
            for (int j = 0; j < 10; j++) {
                System.out.print(t[i][j] + "  ");
            }
            System.out.println();
        }
    }
}