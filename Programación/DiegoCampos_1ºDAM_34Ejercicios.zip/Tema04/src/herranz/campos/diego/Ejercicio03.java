package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio03 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Este programa pide las coordenadas (x1, y1) y (x2, y2) de dos vectores.
        // Luego muestra su suma vectorial y su producto escalar.
        // Presenta el resultado con paréntesis y con corchetes.

        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce x1: ");
        int x1 = sc.nextInt();

        System.out.print("Introduce y1: ");
        int y1 = sc.nextInt();

        System.out.print("Introduce x2: ");
        int x2 = sc.nextInt();

        System.out.print("Introduce y2: ");
        int y2 = sc.nextInt();

        int sumaX = x1 + x2;
        int sumaY = y1 + y2;
        int productoEscalar = (x1 * x2) + (y1 * y2);

        System.out.println();
        System.out.println("(" + x1 + "," + y1 + ")+(" + x2 + "," + y2 + ")=(" + sumaX + "," + sumaY + ")");
        System.out.println("(" + x1 + "," + y1 + ").(" + x2 + "," + y2 + ")= " + productoEscalar);

        System.out.println();
        System.out.println("[" + x1 + "," + y1 + "]+[" + x2 + "," + y2 + "]=[" + sumaX + "," + sumaY + "]");
        System.out.println("[" + x1 + "," + y1 + "].[" + x2 + "," + y2 + "]= " + productoEscalar);

        sc.close();
    }
}
