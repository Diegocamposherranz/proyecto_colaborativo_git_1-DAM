package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio06 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Este programa pide al usuario los valores de un array y un número n.
        // Luego muestra el primer elemento del array y todos los que pueda,
        // saltando de n en n posiciones.

        Scanner sc = new Scanner(System.in);

        System.out.print("¿Cuántos elementos tendrá el array? (máximo 30): ");
        int tam = sc.nextInt();
        if (tam > 30) tam = 30;

        int[] a = new int[tam];

        // Leer los elementos del array
        for (int i = 0; i < tam; i++) {
            System.out.print("Elemento " + (i + 1) + ": ");
            a[i] = sc.nextInt();
        }

        // Leer el salto n
        System.out.print("Introduce el valor de n (salto): ");
        int n = sc.nextInt();

        System.out.println("\nElementos del array saltando de " + n + " en " + n + ":");

        // Mostrar los elementos con salto de n
        for (int i = 0; i < tam; i += n) {
            System.out.println("Índice " + i + ": " + a[i]);
        }

        sc.close();
    }
}