package herranz.campos.diego;

public class Ejercicio11 {

    // Método estático que implementa el algoritmo de la burbuja
    public static int[] burbuja(int[] array) {
        // TODO Auto-generated method stub
    	// Implementar el algoritmo de ordenación por el método de la burbuja, en un método 
    	// estático cuyo prototipo es burbuja(int[ ] ):int[ ] 
        
    	// Este método recibe un array de enteros y lo ordena mediante el método de la burbuja.
        int n = array.length;
        boolean cambio;

        do {
            cambio = false;
            for (int i = 0; i < n - 1; i++) {
                if (array[i] > array[i + 1]) {
                    int temp = array[i];
                    array[i] = array[i + 1];
                    array[i + 1] = temp;
                    cambio = true;
                }
            }
            n--;
        } while (cambio);

        return array;
    }
}