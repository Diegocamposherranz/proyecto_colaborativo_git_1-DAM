package herranz.campos.diego;

public class Ejercicio27 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Crear un método init(): String[][] que cree un tablero propio “vacío” del juego de los barcos,
        // es decir, que en todas sus 10x10 casillas esté contenido el carácter punto “.”.

        // Creamos el tablero vacío usando el método init()
        String[][] tablero = init();

        // Mostramos el tablero generado
        mostrar(tablero);
    }

    // Método que crea un tablero vacío de 10x10 relleno con "."
    public static String[][] init() {
        String[][] t = new String[10][10];

        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t[i].length; j++) {
                t[i][j] = "."; // inicializa todas las casillas con punto
            }
        }

        return t;
    }

    // Método auxiliar para mostrar el tablero con etiquetas (como en el ejercicio 26)
    public static void mostrar(String[][] t) {
        char[] letrasFilas = {'A','B','C','D','E','F','G','H','I','J'};

        System.out.println("=== Tablero Vacío ===\n");

        // Mostrar cabecera de columnas
        System.out.print("   ");
        for (int col = 1; col <= t[0].length; col++) {
            System.out.printf("%-3d", col);
        }
        System.out.println();

        // Mostrar filas
        for (int i = 0; i < t.length; i++) {
            System.out.print(letrasFilas[i] + "  ");
            for (int j = 0; j < t[i].length; j++) {
                System.out.print(t[i][j] + "  ");
            }
            System.out.println();
        }
    }
}