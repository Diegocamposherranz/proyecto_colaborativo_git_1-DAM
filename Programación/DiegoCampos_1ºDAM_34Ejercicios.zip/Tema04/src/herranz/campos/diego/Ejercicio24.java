package herranz.campos.diego;

public class Ejercicio24 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Crear un array “t” de tipo String[][] de 10x10 casillas “hard-coded” que contenga
        // cualquier combinación de los caracteres “O”, “.”, “X” o el espacio “ ”.
        // La distribución debe simular un tablero del juego "Hundir la flota":
        // - "." representa agua
        // - "O" representa una parte de un barco
        // - "X" representa una parte de un barco dañada
        // - " " representa una casilla con contenido desconocido

        String[][] t = {
            {" ", " ", ".", ".", ".", ".", " ", " ", " ", " "},
            {".", ".", ".", "O", ".", ".", ".", " ", " ", " "},
            {".", "O", "O", "O", ".", ".", ".", ".", ".", " "},
            {".", ".", ".", ".", ".", "X", ".", ".", ".", " "},
            {".", ".", ".", ".", ".", "X", ".", ".", ".", "."},
            {" ", ".", ".", ".", ".", ".", ".", ".", ".", "."},
            {" ", " ", ".", ".", "O", "O", "O", ".", ".", "."},
            {" ", " ", ".", ".", ".", ".", ".", ".", ".", "."},
            {" ", " ", ".", ".", ".", ".", ".", " ", ".", "."},
            {" ", " ", ".", ".", ".", ".", ".", ".", ".", " "}
        };

        // Mostrar el tablero
        mostrarTablero(t);
    }

    // Método que muestra el tablero en formato visual
    public static void mostrarTablero(String[][] tablero) {
        System.out.println("=== Tablero de Hundir la Flota ===");
        for (int i = 0; i < tablero.length; i++) {
            for (int j = 0; j < tablero[i].length; j++) {
                System.out.print(tablero[i][j] + " ");
            }
            System.out.println();
        }
    }
}
