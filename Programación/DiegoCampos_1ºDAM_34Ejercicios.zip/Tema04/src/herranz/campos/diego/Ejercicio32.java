package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio32 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub

        // Ejercicio 32:
        // Mejorar el programa para habilitar el juego para dos jugadores:
        // Cada jugador tendrá su propio tablero y colocará sus barcos.
        // Ambos jugadores colocarán 2 barcos de tamaño 2, 2 de tamaño 3 y 1 de tamaño 4.

        Scanner sc = new Scanner(System.in);

        System.out.println("=== 🚢 HUNDIR LA FLOTA - MODO 2 JUGADORES ===\n");

        // Crear tableros para los dos jugadores
        String[][] tablero1 = init();
        String[][] tablero2 = init();

        // Colocar barcos para jugador 1
        System.out.println("🧭 TURNO DEL JUGADOR 1\n");
        colocarFlota(tablero1, sc);

        // Colocar barcos para jugador 2
        System.out.println("\n🧭 TURNO DEL JUGADOR 2\n");
        colocarFlota(tablero2, sc);

        // Mostrar tableros finales
        System.out.println("\n✅ TODOS LOS BARCOS HAN SIDO COLOCADOS");
        System.out.println("\n--- TABLERO JUGADOR 1 ---");
        mostrar(tablero1);

        System.out.println("\n--- TABLERO JUGADOR 2 ---");
        mostrar(tablero2);

        sc.close();
    }

    // ================================
    // MÉTODOS AUXILIARES
    // ================================

    // Coloca toda la flota de un jugador
    public static void colocarFlota(String[][] tablero, Scanner sc) {
        int[] tamanios = {2, 2, 3, 3, 4};
        int numBarco = 1;

        for (int tam : tamanios) {
            boolean colocado = false;
            while (!colocado) {
                System.out.println("\nColoca el barco #" + numBarco + " de tamaño " + tam);
                System.out.print("Introduce <letra> <número> <H/V> (ej: B 5 H): ");

                String fila = sc.next();
                String columna = sc.next();
                String hv = sc.next();

                int resultado = ubicar(tablero, fila, columna, hv, tam);

                switch (resultado) {
                    case 0:
                        System.out.println("✅ Barco colocado correctamente.");
                        colocado = true;
                        break;
                    case -1:
                        System.out.println("❌ Error: el barco se sale de los límites del tablero.");
                        break;
                    case -2:
                        System.out.println("⚠️ Error: el barco está adyacente o sobre otro.");
                        break;
                    default:
                        System.out.println("❗ Error desconocido al colocar el barco.");
                        break;
                }

                mostrar(tablero);
            }
            numBarco++;
        }
    }

    // Crea un tablero vacío (10x10)
    public static String[][] init() {
        String[][] t = new String[10][10];
        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                t[i][j] = ".";
            }
        }
        return t;
    }

    // Coloca un barco en el tablero según las coordenadas
    public static int ubicar(String[][] t, String fila, String columna, String hv, int tam) {
        try {
            int filaNum = fila.toUpperCase().charAt(0) - 'A';
            int colNum = Integer.parseInt(columna) - 1;

            // Validaciones de límites
            if (filaNum < 0 || filaNum >= 10 || colNum < 0 || colNum >= 10) return -1;
            if (tam < 2 || tam > 4) return -3;
            if (hv.equalsIgnoreCase("H") && colNum + tam > 10) return -1;
            if (hv.equalsIgnoreCase("V") && filaNum + tam > 10) return -1;

            // Comprobar adyacencias
            for (int i = 0; i < tam; i++) {
                int f = filaNum + (hv.equalsIgnoreCase("V") ? i : 0);
                int c = colNum + (hv.equalsIgnoreCase("H") ? i : 0);
                for (int df = -1; df <= 1; df++) {
                    for (int dc = -1; dc <= 1; dc++) {
                        int nf = f + df;
                        int nc = c + dc;
                        if (nf >= 0 && nf < 10 && nc >= 0 && nc < 10) {
                            if (t[nf][nc].equals("O")) return -2;
                        }
                    }
                }
            }

            // Colocar barco
            for (int i = 0; i < tam; i++) {
                int f = filaNum + (hv.equalsIgnoreCase("V") ? i : 0);
                int c = colNum + (hv.equalsIgnoreCase("H") ? i : 0);
                t[f][c] = "O";
            }

            return 0;
        } catch (Exception e) {
            return -3;
        }
    }

    // Muestra el tablero con letras y números
    public static void mostrar(String[][] t) {
        char[] letrasFilas = {'A','B','C','D','E','F','G','H','I','J'};

        System.out.println("\n   1  2  3  4  5  6  7  8  9 10");
        for (int i = 0; i < 10; i++) {
            System.out.print(letrasFilas[i] + "  ");
            for (int j = 0; j < 10; j++) {
                System.out.print(t[i][j] + "  ");
            }
            System.out.println();
        }
    }
}