package herranz.campos.diego;

public class Ejercicio18 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        
        // Ejercicio 18:
        // Crear una pseudo base de datos utilizando arrays, que guarde la información de las siguientes personas:
        // DNI | NOMBRE | APELLIDO
        // 1   | Pepe   | Sánchez
        // 2   | Ana    | García
        // 3   | Juan   | Palomo
        // Listarlas con el siguiente formato: <Apellido>, <Nombre> (<DNI>)

        // Arrays paralelos para guardar los datos
        int[] dni = {1, 2, 3};
        String[] nombres = {"Pepe", "Ana", "Juan"};
        String[] apellidos = {"Sánchez", "García", "Palomo"};

        // Mostrar la información en el formato solicitado
        System.out.println("Listado de personas:\n");
        for (int i = 0; i < dni.length; i++) {
            System.out.println(apellidos[i] + ", " + nombres[i] + " (" + dni[i] + ")");
        }
    }
}