package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio02 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Este programa pide hasta 30 números enteros (o hasta que se introduzca 0).
        // Calcula el máximo, el mínimo y la media aritmética (incluyéndolos).
        // Luego muestra la lista sin el máximo ni el mínimo.

        Scanner sc = new Scanner(System.in);
        int[] numeros = new int[30];
        int contador = 0;
        int num;

        System.out.println("Introduce números enteros (0 para terminar, máximo 30):");

        do {
            System.out.print("Número " + (contador + 1) + ": ");
            num = sc.nextInt();

            if (num != 0) {
                numeros[contador] = num;
                contador++;
            }

        } while (num != 0 && contador < 30);

        if (contador == 0) {
            System.out.println("No se han introducido números.");
        } else {
            int max = maximo(numeros, contador);
            int min = minimo(numeros, contador);
            double media = mediaAritmetica(numeros, contador);

            System.out.print("\nNúmeros introducidos (sin máximo ni mínimo): ");
            boolean primero = true;
            for (int i = 0; i < contador; i++) {
                if (numeros[i] != max && numeros[i] != min) {
                    if (!primero) System.out.print(", ");
                    System.out.print(numeros[i]);
                    primero = false;
                }
            }

            System.out.println("\nMáximo: " + max);
            System.out.println("Mínimo: " + min);
            System.out.printf("Media aritmética: %.2f%n", media);
        }

        sc.close();
    }

    // Método que calcula el valor máximo en el array
    public static int maximo(int[] array, int n) {
        int max = array[0];
        for (int i = 1; i < n; i++) {
            if (array[i] > max)
                max = array[i];
        }
        return max;
    }

    // Método que calcula el valor mínimo en el array
    public static int minimo(int[] array, int n) {
        int min = array[0];
        for (int i = 1; i < n; i++) {
            if (array[i] < min)
                min = array[i];
        }
        return min;
    }

    // Método que calcula la media aritmética de los números introducidos
    public static double mediaAritmetica(int[] array, int n) {
        double suma = 0;
        for (int i = 0; i < n; i++) {
            suma += array[i];
        }
        return suma / n;
    }
}