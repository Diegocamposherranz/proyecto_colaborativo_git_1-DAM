package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio16 {

    public static void main(String[] args) {
        int[][] A = new int[3][3];
        int[][] B = new int[3][3];
        int[][] suma = new int[3][3];
        int[][] producto = new int[3][3];
        int[] datos = new int[18];

        if (args.length != 18) {
            System.out.println("No se recibieron 18 argumentos. Usando valores por defecto...\n");

            Scanner sc = new Scanner(System.in);
            System.out.print("Introduce 18 números separados por espacios (o presiona Enter para usar los valores por defecto): ");
            String linea = sc.nextLine().trim();

            if (linea.isEmpty()) {
                // valores por defecto
                linea = "1 2 3 4 5 6 7 8 9 9 8 7 6 5 4 3 2 1";
            }

            String[] partes = linea.split("\\s+");
            if (partes.length != 18) {
                System.out.println("Error: debes introducir exactamente 18 números.");
                sc.close();
                return;
            }

            for (int i = 0; i < 18; i++) {
                datos[i] = Integer.parseInt(partes[i]);
            }
            sc.close();
        } else {
            for (int i = 0; i < 18; i++) {
                datos[i] = Integer.parseInt(args[i]);
            }
        }

        // Rellenar matrices A y B
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                A[i][j] = datos[i * 3 + j];
                B[i][j] = datos[9 + i * 3 + j];
            }
        }

        // Calcular suma
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                suma[i][j] = A[i][j] + B[i][j];
            }
        }

        // Calcular producto
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                producto[i][j] = 0;
                for (int k = 0; k < 3; k++) {
                    producto[i][j] += A[i][k] * B[k][j];
                }
            }
        }

        // Mostrar resultados
        System.out.println("\nMatriz A:");
        mostrarMatriz(A);

        System.out.println("Matriz B:");
        mostrarMatriz(B);

        System.out.println("Suma de A + B:");
        mostrarMatriz(suma);

        System.out.println("Producto de A x B:");
        mostrarMatriz(producto);
    }

    // Método auxiliar para mostrar matrices 3x3
    public static void mostrarMatriz(int[][] m) {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(m[i][j] + "\t");
            }
            System.out.println();
        }
        System.out.println();
    }
}