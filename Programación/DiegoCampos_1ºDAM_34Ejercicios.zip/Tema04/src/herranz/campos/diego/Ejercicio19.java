package herranz.campos.diego;

public class Ejercicio19 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // A partir de la pseudo base de datos del ejercicio anterior,
        // listar sólo los nombres de las personas guardadas en los arrays.

        // Arrays con los datos de las personas
        int[] dni = {1, 2, 3};
        String[] nombres = {"Pepe", "Ana", "Juan"};
        String[] apellidos = {"Sánchez", "García", "Palomo"};

        // Mostrar únicamente los nombres
        System.out.println("Listado de nombres:\n");
        for (int i = 0; i < nombres.length; i++) {
            System.out.println(nombres[i]);
        }
    }
}
