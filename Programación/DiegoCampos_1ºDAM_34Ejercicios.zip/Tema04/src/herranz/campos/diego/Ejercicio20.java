package herranz.campos.diego;

public class Ejercicio20 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Listar sólo la columna que se indique (columna puede valer “nombre”, “apellido”, “dni” o “todo”).
        // “todo” mostraría todos los datos de cada persona en el siguiente formato:
        // <dni> <nombre> <apellido>
        // Cada filtro mostrará solo la columna indicada.
        // PISTA: Crear un método toString(String[][] datos, String columna)
        // que devuelva el String a mostrar.

        // Datos de ejemplo (pseudo base de datos)
        String[][] datos = {
            {"1", "Pepe", "Sánchez"},
            {"2", "Ana", "García"},
            {"3", "Juan", "Palomo"}
        };

        // Si no se pasa argumento, avisamos al usuario
        if (args.length == 0) {
            System.out.println("Uso: java herranz.campos.diego.Ejercicio20 <columna>");
            System.out.println("Donde <columna> puede ser: dni | nombre | apellido | todo");
            return;
        }

        String columna = args[0].toLowerCase(); // argumento pasado (columna a mostrar)

        // Mostramos el resultado usando el método toString
        System.out.println(toString(datos, columna));
    }

    // Método que devuelve un String con el contenido según la columna elegida
    public static String toString(String[][] datos, String columna) {
        StringBuilder sb = new StringBuilder();

        switch (columna) {
            case "dni":
                for (int i = 0; i < datos.length; i++) {
                    sb.append(datos[i][0]).append("\n");
                }
                break;

            case "nombre":
                for (int i = 0; i < datos.length; i++) {
                    sb.append(datos[i][1]).append("\n");
                }
                break;

            case "apellido":
                for (int i = 0; i < datos.length; i++) {
                    sb.append(datos[i][2]).append("\n");
                }
                break;

            case "todo":
                for (int i = 0; i < datos.length; i++) {
                    sb.append(datos[i][0]).append(" ")
                      .append(datos[i][1]).append(" ")
                      .append(datos[i][2]).append("\n");
                }
                break;

            default:
                sb.append("Columna no válida. Usa: dni | nombre | apellido | todo");
        }

        return sb.toString();
    }
}