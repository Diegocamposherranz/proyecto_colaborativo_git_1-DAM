package herranz.campos.diego;

import java.util.Scanner;

public class Ejercicio07 {

    public static void main(String[] args) {
        // Este programa pide al usuario un número n y una lista de elementos.
        // Luego muestra el primero y los siguientes saltando de n en n posiciones.
        // Ejemplo:
        // n = 3
        // elementos = a b c d e f g h i j k l m n o
        // Salida: a d g j m

        Scanner sc = new Scanner(System.in);

        System.out.print("Introduce el número n: ");
        int n = sc.nextInt();
        sc.nextLine(); // limpiar salto de línea

        System.out.print("Introduce los elementos separados por espacios: ");
        String linea = sc.nextLine();

        String[] elementos = linea.split("\\s+");

        System.out.println("\nElementos saltando de " + n + " en " + n + ":");

        for (int i = 0; i < elementos.length; i += n) {
            System.out.print(elementos[i] + " ");
        }

        System.out.println();
        sc.close();
    }
}