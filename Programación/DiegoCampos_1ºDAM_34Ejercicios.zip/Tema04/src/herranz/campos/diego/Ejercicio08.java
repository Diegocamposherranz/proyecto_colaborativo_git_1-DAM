package herranz.campos.diego;

public class Ejercicio08 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Programa Calculadora: recibe tres argumentos -> operación, operando1 y operando2
        // Uso: java Ejercicio08 <operacion> <op1> <op2>
        // Operaciones: suma, resta, mul, div

        if (args.length != 3) {
            System.out.println("Uso: java Ejercicio08 <operacion> <op1> <op2>");
            return;
        }

        String operacion = args[0];
        double op1 = Double.parseDouble(args[1]);
        double op2 = Double.parseDouble(args[2]);
        double resultado = 0;

        switch (operacion) {
            case "suma":
                resultado = op1 + op2;
                break;
            case "resta":
                resultado = op1 - op2;
                break;
            case "mul":
                resultado = op1 * op2;
                break;
            case "div":
                if (op2 != 0)
                    resultado = op1 / op2;
                else {
                    System.out.println("Error: división por cero");
                    return;
                }
                break;
            default:
                System.out.println("Operación no válida. Use: suma, resta, mul o div.");
                return;
        }

        System.out.println("Resultado: " + resultado);
    }
}