package herranz.campos.diego;

public class Ejercicio29 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        // Crear un método ubicar(t: String[][], fila:String, columna:String, hv:String, tam:int):int
        // que ubique en el tablero propio “t” un barco de tamaño “tam” (entre 2 y 4 casillas)
        // en las coordenadas “fila” y “columna”.
        // “hv” indica si el barco se debe extender en horizontal (“H”) o vertical (“V”).
        // El método devolverá:
        //  0 → posicionamiento correcto
        // -1 → el barco se sale de los límites
        // -2 → el barco queda adyacente a otro
        // -3 → cualquier otro error

        // Crear tablero vacío
        String[][] tablero = init();

        // Ejemplo: colocar un barco horizontal de tamaño 3 empezando en B3
        int resultado = ubicar(tablero, "B", "3", "H", 3);
        System.out.println("Resultado: " + resultado);

        // Mostrar el tablero tras ubicar
        mostrar(tablero);
    }

    // Inicializa tablero vacío con "."
    public static String[][] init() {
        String[][] t = new String[10][10];
        for (int i = 0; i < t.length; i++) {
            for (int j = 0; j < t[i].length; j++) {
                t[i][j] = ".";
            }
        }
        return t;
    }

    // Método que ubica un barco
    public static int ubicar(String[][] t, String fila, String columna, String hv, int tam) {
        try {
            int filaNum = fila.toUpperCase().charAt(0) - 'A'; // convierte "A".."J" en 0..9
            int colNum = Integer.parseInt(columna) - 1;       // convierte "1".."10" en 0..9

            // Validaciones básicas
            if (filaNum < 0 || filaNum >= 10 || colNum < 0 || colNum >= 10) {
                return -1; // fuera del tablero
            }
            if (tam < 2 || tam > 4) {
                return -3; // tamaño inválido
            }

            // Verificar límites según orientación
            if (hv.equalsIgnoreCase("H") && colNum + tam > 10) return -1;
            if (hv.equalsIgnoreCase("V") && filaNum + tam > 10) return -1;

            // Verificar adyacencias (ninguna casilla del barco ni vecinas puede contener "O")
            for (int i = 0; i < tam; i++) {
                int f = filaNum + (hv.equalsIgnoreCase("V") ? i : 0);
                int c = colNum + (hv.equalsIgnoreCase("H") ? i : 0);

                // Revisa las 8 casillas alrededor
                for (int df = -1; df <= 1; df++) {
                    for (int dc = -1; dc <= 1; dc++) {
                        int nf = f + df;
                        int nc = c + dc;
                        if (nf >= 0 && nf < 10 && nc >= 0 && nc < 10) {
                            if (t[nf][nc].equals("O")) {
                                return -2; // adyacente a otro barco
                            }
                        }
                    }
                }
            }

            // Si todo está bien, coloca el barco
            for (int i = 0; i < tam; i++) {
                int f = filaNum + (hv.equalsIgnoreCase("V") ? i : 0);
                int c = colNum + (hv.equalsIgnoreCase("H") ? i : 0);
                t[f][c] = "O";
            }

            return 0; // correcto ✅

        } catch (Exception e) {
            return -3; // error inesperado
        }
    }

    // Muestra el tablero con etiquetas
    public static void mostrar(String[][] t) {
        char[] letrasFilas = {'A','B','C','D','E','F','G','H','I','J'};

        System.out.println("\n=== Tablero Actual ===\n");

        // Cabecera columnas
        System.out.print("   ");
        for (int col = 1; col <= 10; col++) {
            System.out.printf("%-3d", col);
        }
        System.out.println();

        // Filas
        for (int i = 0; i < 10; i++) {
            System.out.print(letrasFilas[i] + "  ");
            for (int j = 0; j < 10; j++) {
                System.out.print(t[i][j] + "  ");
            }
            System.out.println();
        }
    }
}